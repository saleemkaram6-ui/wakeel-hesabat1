package com.wakeel.hesabat;

import android.content.Context;
import android.content.SharedPreferences;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

/** Configurable discount percentages by application name. */
public final class DiscountStore {
  private static final String PREFS="agent";
  private static final String KEY="discount_rules_v2";
  private DiscountStore(){}

  private static String cleanName(String s){return s==null?"":s.trim().replace('\t',' ').replace('\n',' ').replaceAll("\\s+"," ");}
  private static String key(String s){return cleanName(s).toLowerCase(Locale.ROOT);}
  private static BigDecimal parsePercent(String s){
    try{
      String v=AccountMessage.digits(s==null?"":s.trim()).replace('٫','.').replace(',','.');
      BigDecimal p=new BigDecimal(v).setScale(2,RoundingMode.HALF_UP);
      if(p.compareTo(BigDecimal.ZERO)<0||p.compareTo(new BigDecimal("100"))>0)return null;
      return p;
    }catch(Exception e){return null;}
  }
  private static String initial(){
    // Keep the previous 7% behavior as editable starter rules only.
    return "زافا\t7\nزلفة\t7\nالزلفة\t7";
  }
  private static String raw(Context c){
    SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
    if(!p.contains(KEY))p.edit().putString(KEY,initial()).apply();
    return p.getString(KEY,"");
  }
  public static LinkedHashMap<String,BigDecimal> all(Context c){
    LinkedHashMap<String,BigDecimal> out=new LinkedHashMap<>();
    for(String line:raw(c).split("\\n")){
      String[] a=line.split("\\t",-1); if(a.length!=2)continue;
      String name=cleanName(a[0]); BigDecimal pct=parsePercent(a[1]);
      if(!name.isEmpty()&&pct!=null)out.put(name,pct);
    }
    return out;
  }
  public static BigDecimal percent(Context c,String app){
    String wanted=key(app);
    for(Map.Entry<String,BigDecimal> e:all(c).entrySet())if(key(e.getKey()).equals(wanted))return e.getValue();
    return null;
  }
  public static boolean save(Context c,String app,String percent){
    String name=cleanName(app); BigDecimal pct=parsePercent(percent); if(name.isEmpty()||pct==null)return false;
    LinkedHashMap<String,BigDecimal> map=all(c); String replace=null;
    for(String n:map.keySet())if(key(n).equals(key(name))){replace=n;break;}
    if(replace!=null)map.remove(replace); map.put(name,pct); write(c,map); return true;
  }
  public static void delete(Context c,String app){
    LinkedHashMap<String,BigDecimal> map=all(c); String remove=null;
    for(String n:map.keySet())if(key(n).equals(key(app))){remove=n;break;}
    if(remove!=null){map.remove(remove);write(c,map);}
  }
  private static void write(Context c,LinkedHashMap<String,BigDecimal> map){
    StringBuilder b=new StringBuilder();
    for(Map.Entry<String,BigDecimal> e:map.entrySet()){
      if(b.length()>0)b.append('\n');
      b.append(cleanName(e.getKey())).append('\t').append(e.getValue().stripTrailingZeros().toPlainString());
    }
    c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY,b.toString()).apply();
  }
  public static BigDecimal discount(BigDecimal gross,BigDecimal pct){
    if(pct==null)return BigDecimal.ZERO.setScale(2,RoundingMode.HALF_UP);
    return gross.multiply(pct).divide(new BigDecimal("100"),2,RoundingMode.HALF_UP);
  }
}
