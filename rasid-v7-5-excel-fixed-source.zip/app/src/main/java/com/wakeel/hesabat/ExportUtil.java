package com.wakeel.hesabat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextDirectionHeuristics;
import android.text.TextPaint;
import java.io.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public final class ExportUtil {
  private ExportUtil(){}
  public static final String[] HEADERS={"التاريخ والوقت","المرسل/المحادثة","ID","المبلغ بالدولار","التطبيق","اسم المجموعة","نسبة الخصم","قيمة الخصم","الصافي بالدولار","الحالة"};

  public static List<String[]> rows(String raw){
    ArrayList<String[]> rows=new ArrayList<>();
    if(raw==null||raw.trim().isEmpty())return rows;
    for(String line:raw.split("\\n")){
      String[] c=line.split("\\t",-1);
      if(c.length>=10)rows.add(Arrays.copyOf(c,10));
    }
    return rows;
  }

  private static String xml(String s){
    if(s==null)return "";
    return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");
  }
  private static String col(int index){
    StringBuilder b=new StringBuilder(); int n=index+1;
    while(n>0){n--;b.insert(0,(char)('A'+(n%26)));n/=26;}
    return b.toString();
  }
  private static void entry(ZipOutputStream z,String name,String value)throws IOException{
    z.putNextEntry(new ZipEntry(name));z.write(value.getBytes("UTF-8"));z.closeEntry();
  }

  public static void writeXlsx(Context c,Uri uri,String raw)throws IOException{
    List<String[]> data=rows(raw);
    try(OutputStream os=c.getContentResolver().openOutputStream(uri);ZipOutputStream z=new ZipOutputStream(os)){
      entry(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");
      entry(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");
      entry(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"تقرير الحسابات\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");
      entry(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");
      StringBuilder s=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetViews><sheetView workbookViewId=\"0\" rightToLeft=\"1\"/></sheetViews><sheetData>");
      appendRow(s,1,HEADERS);
      int row=2;for(String[] r:data)appendRow(s,row++,r);
      s.append("</sheetData>");
      if(row>2)s.append("<autoFilter ref=\"A1:J").append(row-1).append("\"/>");
      s.append("</worksheet>");
      entry(z,"xl/worksheets/sheet1.xml",s.toString());
    }
  }
  private static void appendRow(StringBuilder s,int row,String[] values){
    s.append("<row r=\"").append(row).append("\">");
    for(int i=0;i<values.length;i++){
      String ref=col(i)+row;
      String value=values[i]==null?"":values[i].trim();
      // Amounts must be numeric cells so Excel pivot tables can sum them.
      if(row>1&&(i==3||i==7||i==8)&&value.matches("-?[0-9]+(\\.[0-9]+)?"))
        s.append("<c r=\"").append(ref).append("\"><v>").append(value).append("</v></c>");
      else
        s.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(xml(values[i])).append("</t></is></c>");
    }
    s.append("</row>");
  }

  public static void writePdf(Context c,Uri uri,String raw)throws IOException{
    List<String[]> data=rows(raw);
    PdfDocument doc=new PdfDocument();
    TextPaint titlePaint=new TextPaint(Paint.ANTI_ALIAS_FLAG);titlePaint.setColor(Color.rgb(18,70,130));titlePaint.setTextSize(24);titlePaint.setTypeface(Typeface.create(Typeface.DEFAULT,Typeface.BOLD));
    TextPaint bodyPaint=new TextPaint(Paint.ANTI_ALIAS_FLAG);bodyPaint.setColor(Color.rgb(35,35,35));bodyPaint.setTextSize(12);
    Paint line=new Paint(Paint.ANTI_ALIAS_FLAG);line.setColor(Color.rgb(220,225,232));
    int pageNo=0,y=0;PdfDocument.Page page=null;Canvas canvas=null;
    try{
      for(int i=0;i<Math.max(1,data.size());i++){
        if(page==null||y>720){
          if(page!=null)doc.finishPage(page);
          pageNo++;page=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,pageNo).create());canvas=page.getCanvas();
          drawRtl(canvas,"رصيد — تقرير الحسابات",titlePaint,40,34,515,44);y=92;
        }
        if(data.isEmpty()){
          drawRtl(canvas,"لا توجد سجلات حسابية حتى الآن.",bodyPaint,40,y,515,50);y+=60;break;
        }
        String[] r=data.get(i);
        String text="ID: "+r[2]+"    |    التطبيق: "+r[4]+"\n"+
          "المبلغ: "+r[3]+"$    |    الخصم: "+r[6]+" ("+r[7]+"$)    |    الصافي: "+r[8]+"$\n"+
          "المجموعة: "+(r[5].isEmpty()?"—":r[5])+"    |    التاريخ: "+r[0]+"\n"+
          "الحالة: "+r[9];
        canvas.drawRect(40,y-8,555,y+100,line);
        drawRtl(canvas,text,bodyPaint,50,y,495,92);y+=118;
      }
      if(page!=null)doc.finishPage(page);
      try(OutputStream out=c.getContentResolver().openOutputStream(uri)){doc.writeTo(out);}
    }finally{doc.close();}
  }
  private static void drawRtl(Canvas canvas,String text,TextPaint paint,int x,int y,int width,int height){
    StaticLayout layout=StaticLayout.Builder.obtain(text,0,text.length(),paint,width)
      .setAlignment(Layout.Alignment.ALIGN_OPPOSITE).setTextDirection(TextDirectionHeuristics.RTL)
      .setIncludePad(false).setMaxLines(Math.max(1,height/16)).build();
    canvas.save();canvas.translate(x,y);layout.draw(canvas);canvas.restore();
  }
}
