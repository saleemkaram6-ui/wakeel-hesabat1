package com.wakeel.hesabat;

import android.content.Context;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

/** Local accounting rows. One WhatsApp accounting message = one TSV row. */
public final class RecordStore {
  private static final String FILE="pending.tsv";
  private RecordStore(){}

  public static synchronized String read(Context c){
    try(FileInputStream in=c.openFileInput(FILE)){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1)b.write(buf,0,n);return new String(b.toByteArray(),"UTF-8");}
    catch(Exception e){return "";}
  }
  public static synchronized void append(Context c,String row){
    try(FileOutputStream out=c.openFileOutput(FILE,Context.MODE_APPEND)){out.write(row.getBytes("UTF-8"));}catch(Exception ignored){}
  }
  private static ArrayList<String[]> rows(Context c){
    ArrayList<String[]> out=new ArrayList<>();
    String raw=read(c);if(raw.isEmpty())return out;
    for(String line:raw.split("\\n")){String[] x=line.split("\\t",-1);if(x.length>=10)out.add(Arrays.copyOf(x,10));}
    return out;
  }
  private static void writeRows(Context c,List<String[]> rows){
    StringBuilder b=new StringBuilder();
    for(String[] r:rows){for(int i=0;i<10;i++){if(i>0)b.append('\t');b.append((r[i]==null?"":r[i]).replace('\t',' ').replace('\n',' '));}b.append('\n');}
    try(FileOutputStream out=c.openFileOutput(FILE,Context.MODE_PRIVATE)){out.write(b.toString().getBytes("UTF-8"));}catch(Exception ignored){}
  }
  private static BigDecimal money(String s){try{return new BigDecimal(s).setScale(2,RoundingMode.HALF_UP);}catch(Exception e){return BigDecimal.ZERO.setScale(2);}}
  private static boolean approved(String status){return status!=null&&(status.contains("معتمد")||status.contains("تم التفاعل"));}

  /** Approve only the newest matching pending record, never all same-ID rows. */
  public static synchronized boolean markApproved(Context c,AccountMessage m){
    ArrayList<String[]> data=rows(c);
    for(int i=data.size()-1;i>=0;i--){
      String[] r=data.get(i);
      if(r[2].equals(m.id)&&r[3].equals(m.gross().toPlainString())&&r[4].equals(m.app)){
        if(!approved(r[9])){
          r[9]=r[6].equals("غير محدد")?"تم التفاعل 🖥️ — الخصم غير محدد":"معتمد بتفاعل 🖥️";
          writeRows(c,data);return true;
        }
        return false;
      }
    }
    return false;
  }

  /** Recalculate existing rows after a discount rule is added or changed. */
  public static synchronized void recalculate(Context c){
    ArrayList<String[]> data=rows(c);boolean changed=false;
    for(String[] r:data){
      BigDecimal gross=money(r[3]);BigDecimal pct=DiscountStore.percent(c,r[4]);boolean ok=pct!=null;boolean wasApproved=approved(r[9]);
      BigDecimal d=DiscountStore.discount(gross,pct);BigDecimal net=gross.subtract(d);
      String p=ok?pct.stripTrailingZeros().toPlainString()+"%":"غير محدد";
      String status=wasApproved?(ok?"معتمد بتفاعل 🖥️":"تم التفاعل 🖥️ — الخصم غير محدد"):(ok?"بانتظار التفاعل 🖥️":"بانتظار تحديد الخصم والتفاعل");
      if(!r[6].equals(p)||!r[7].equals(d.toPlainString())||!r[8].equals(net.toPlainString())||!r[9].equals(status))changed=true;
      r[6]=p;r[7]=d.toPlainString();r[8]=net.toPlainString();r[9]=status;
    }
    if(changed)writeRows(c,data);
  }
}
