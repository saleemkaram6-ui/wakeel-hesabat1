package com.wakeel.hesabat;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.graphics.Rect;
import java.util.*;

/** Diagnostic only: observes visible UI; never approves an account automatically. */
public class ReactionProbe extends AccessibilityService {
  private long lastAt=0; private String lastLine="";
  @Override public void onAccessibilityEvent(AccessibilityEvent e){
    if(e==null||e.getPackageName()==null||!String.valueOf(e.getPackageName()).matches("com\\.whatsapp(?:\\.w4b)?"))return;
    int type=e.getEventType();if(type!=AccessibilityEvent.TYPE_VIEW_CLICKED&&type!=AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED)return;
    long now=System.currentTimeMillis();if(now-lastAt<500)return;lastAt=now;
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
    ArrayList<String> text=new ArrayList<>(); ArrayList<Rect> positions=new ArrayList<>();collect(root,text,positions,0);root.recycle();
    StringBuilder candidates=new StringBuilder();int matches=0;
    for(int i=0;i<text.size();i++){
      AccountMessage m=AccountMessage.parse(text.get(i));
      if(m==null&&i+2<text.size())m=AccountMessage.parse(text.get(i)+"\n"+text.get(i+1)+"\n"+text.get(i+2));
      if(m!=null){matches++;if(candidates.length()>0)candidates.append(", ");candidates.append(m.id).append(" (").append(m.amount).append(" / ").append(m.app).append(")");}
    }
    boolean reaction=false;for(String s:text)if(s.contains("🖥")||s.contains("🖥️"))reaction=true;
    String line=(type==AccessibilityEvent.TYPE_VIEW_CLICKED?"نقر":"تغير شاشة")+" • مرشحات="+matches+" • رمز 🖥️ ظاهر="+(reaction?"نعم":"لا")+(matches>0?" • "+candidates:"");
    if(line.equals(lastLine))return;lastLine=line;
    ProbeLog.append(this,line);
  }
  private void collect(AccessibilityNodeInfo n,ArrayList<String> text,ArrayList<Rect> positions,int depth){
    if(n==null||depth>30||text.size()>300)return;
    CharSequence t=n.getText();if(t==null)t=n.getContentDescription();if(t!=null){String value=t.toString().trim();if(!value.isEmpty()){text.add(value);Rect r=new Rect();n.getBoundsInScreen(r);positions.add(r);}}
    for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo child=n.getChild(i);if(child!=null){collect(child,text,positions,depth+1);child.recycle();}}
  }
  @Override public void onInterrupt(){}
}
