package com.wakeel.hesabat;

import android.content.Context;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

final class ProbeLog {
  static synchronized void append(Context c,String value){String line=new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())+" • "+value+"\n";
    try(FileOutputStream out=c.openFileOutput("probe.log",Context.MODE_APPEND)){out.write(line.getBytes("UTF-8"));}catch(IOException ignored){}
  }
  static String read(Context c){try(FileInputStream in=c.openFileInput("probe.log")){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){b.write(buf,0,n);if(b.size()>100000)break;}return new String(b.toByteArray(),"UTF-8");}catch(IOException e){return "";}}
}
