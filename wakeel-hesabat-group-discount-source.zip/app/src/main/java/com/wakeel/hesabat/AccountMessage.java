package com.wakeel.hesabat;

import java.util.regex.Pattern;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Strict three-line accounting message. No guesses from unrelated chat text. */
public final class AccountMessage {
  private static final Pattern ID=Pattern.compile("[0-9٠-٩۰-۹]{4,20}");
  private static final Pattern AMOUNT=Pattern.compile("[0-9٠-٩۰-۹]+(?:[.,٫][0-9٠-٩۰-۹]{1,2})?");
  public final String id, amount, app;
  private AccountMessage(String id,String amount,String app){this.id=id;this.amount=amount;this.app=app;}
  static String digits(String s){StringBuilder b=new StringBuilder();for(char c:s.toCharArray()){int v=Character.digit(c,10);b.append(v>=0?(char)('0'+v):c);}return b.toString();}
  public static AccountMessage parse(String raw){if(raw==null)return null;String[] lines=raw.trim().split("\\R");if(lines.length!=3)return null;
    String id=digits(lines[0].trim()), amount=digits(lines[1].trim()).replace('٫','.').replace(',','.');String app=lines[2].trim();
    if(!ID.matcher(id).matches()||!AMOUNT.matcher(amount).matches()||app.isEmpty()||app.length()>60||app.matches("[0-9 .]+"))return null;
    return new AccountMessage(id,amount,app);
  }
  public BigDecimal gross(){return new BigDecimal(amount).setScale(2,RoundingMode.HALF_UP);}
  public BigDecimal discountRate(){String name=app.trim();return (name.equalsIgnoreCase("زافا")||name.equals("زلفة")||name.equals("الزلفة"))?new BigDecimal("0.07"):BigDecimal.ZERO;}
  public BigDecimal discount(){return gross().multiply(discountRate()).setScale(2,RoundingMode.HALF_UP);}
  public BigDecimal net(){return gross().subtract(discount());}
}
