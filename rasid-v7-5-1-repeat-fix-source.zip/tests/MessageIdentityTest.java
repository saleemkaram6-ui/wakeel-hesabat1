package com.wakeel.hesabat;
public final class MessageIdentityTest {
  public static void main(String[] args){
    AccountMessage message=AccountMessage.parse("1214870\n30\nزافا");
    String first=MessageIdentity.key("com.whatsapp.w4b","مجموعة","أحمد",message,1000L);
    String repost=MessageIdentity.key("com.whatsapp.w4b","مجموعة","أحمد",message,1000L);
    String second=MessageIdentity.key("com.whatsapp.w4b","مجموعة","أحمد",message,2000L);
    if(!first.equals(repost)||first.equals(second))throw new AssertionError("Duplicate detection lost a distinct transaction");
    System.out.println("MessageIdentityTest passed");
  }
}
