package com.wakeel.hesabat;

/** Distinguish identical accounting messages delivered at different times. */
public final class MessageIdentity {
  private MessageIdentity(){}
  public static String key(String pkg,String group,String sender,AccountMessage message,long timestamp){
    return pkg+"|"+group+"|"+sender+"|"+message.id+"|"+message.amount+"|"+message.app+"|"+timestamp;
  }
}
