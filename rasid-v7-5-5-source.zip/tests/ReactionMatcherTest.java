package com.wakeel.hesabat;
import java.util.*;
public class ReactionMatcherTest {
 static ReactionMatcher.Node node(String text){ReactionMatcher.Node n=new ReactionMatcher.Node();n.text=text;return n;}
 static ReactionMatcher.Node reactionMeta(){ReactionMatcher.Node n=node("🖥️");n.resource="com.whatsapp:id/reactions";return n;}
 static ReactionMatcher.Node reactionPlain(){return node("🖥️");}
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  ReactionMatcher.Node root=node(""),list=node("");list.boundary=true;root.add(list);
  ReactionMatcher.Node a=node(""),b=node("");a.add(node("9999001\n30\nزافا"));b.add(node("9999002\n50\nزافا"));list.add(a).add(b);
  ReactionMatcher.Node mark=reactionMeta();b.add(mark);
  List<ReactionMatcher.Result> r=ReactionMatcher.match(root);check(r.size()==2&&!r.get(0).linked&&r.get(1).linked);
  b.children.remove(mark);r=ReactionMatcher.match(root);check(!r.get(0).linked&&!r.get(1).linked);
  list.add(reactionMeta());r=ReactionMatcher.match(root);check(!r.get(0).linked&&!r.get(1).linked);
  // Newer WhatsApp builds may expose the reaction chip only as a plain emoji.
  ReactionMatcher.Node plain=reactionPlain();b.add(plain);r=ReactionMatcher.match(root);check(r.get(1).linked);
  b.children.remove(plain);
  // A separate emoji message must not approve either accounting row.
  ReactionMatcher.Node emojiRow=node("");emojiRow.add(reactionPlain());list.add(emojiRow);r=ReactionMatcher.match(root);check(!r.get(0).linked&&!r.get(1).linked);
  a.add(reactionMeta());r=ReactionMatcher.match(root);check(r.get(0).linked&&!r.get(1).linked);
  ReactionMatcher.Node ambiguous=node("");ambiguous.add(node("9999001\n30\nزافا")).add(node("9999002\n50\nزافا")).add(reactionMeta());
  ReactionMatcher.Node win=node("");win.add(ambiguous);r=ReactionMatcher.match(win);check(!r.get(0).linked&&!r.get(1).linked);
  // Some WhatsApp builds split one accounting message across sibling nodes.
  ReactionMatcher.Node splitRoot=node(""),splitList=node("");splitList.boundary=true;splitRoot.add(splitList);
  ReactionMatcher.Node splitBubble=node("");splitBubble.add(node("8888001")).add(node("70")).add(node("زافا")).add(node("15:42")).add(reactionPlain());splitList.add(splitBubble);
  r=ReactionMatcher.match(splitRoot);check(r.size()==1&&r.get(0).message.id.equals("8888001")&&r.get(0).linked);
  System.out.println("PASS: per-message reaction association including plain WhatsApp reaction chips");
 }
}
