package com.wakeel.hesabat;

import android.app.Notification;
import android.app.Person;
import android.os.Build;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.content.SharedPreferences;
import java.math.BigDecimal;
import java.util.*;

/** Reads every accounting message exposed by a WhatsApp notification update. */
public class MessageListener extends NotificationListenerService {
  private static final int RECENT_LIMIT=300;

  @Override public void onNotificationPosted(StatusBarNotification sbn) {
    String pkg=sbn.getPackageName();
    if (!pkg.equals("com.whatsapp") && !pkg.equals("com.whatsapp.w4b")) return;
    Notification notification=sbn.getNotification();
    if (notification==null || (notification.flags & Notification.FLAG_GROUP_SUMMARY)!=0) return;
    Bundle extras=notification.extras;
    if (extras==null) return;

    String title=cleanName(String.valueOf(extras.getCharSequence(Notification.EXTRA_TITLE, "")));
    String conversation=cleanName(String.valueOf(extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE, "")));
    boolean isGroup=extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION,false);
    String group=isGroup?(conversation.isEmpty()?title:conversation):"";

    boolean handled=false;
    android.os.Parcelable[] bundled=extras.getParcelableArray(Notification.EXTRA_MESSAGES);
    if(bundled!=null && bundled.length>0){
      try{
        List<Notification.MessagingStyle.Message> items=Notification.MessagingStyle.Message.getMessagesFromBundleArray(bundled);
        if(items!=null){
          // WhatsApp updates one notification with an expanding list. Reading the
          // entire list here prevents the 2nd/3rd quick message from disappearing.
          for(Notification.MessagingStyle.Message item:items){
            if(item==null || item.getText()==null)continue;
            String body=item.getText().toString().trim();
            AccountMessage parsed=AccountMessage.parse(body);
            if(parsed==null)continue;
            String sender=cleanName(senderOf(item,title));
            if(sender.isEmpty())sender=title;
            long messageTime=item.getTimestamp()>0?item.getTimestamp():stableFallbackTime(notification,sbn);
            try { saveIfNew(pkg,group,sender,parsed,messageTime,sbn.getPostTime()); handled=true; }
            catch(RuntimeException e) { ProbeLog.append(this,"تعذر حفظ رسالة إشعار: "+e.getClass().getSimpleName()); }
          }
        }
      }catch(RuntimeException ignored){}
    }

    // Some WhatsApp versions expose a single message through text lines or big text.
    if(!handled){
      List<CharSequence> candidates=new ArrayList<>();
      CharSequence[] lines=extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
      if(lines!=null)Collections.addAll(candidates,lines);
      CharSequence big=extras.getCharSequence(Notification.EXTRA_BIG_TEXT);
      CharSequence text=extras.getCharSequence(Notification.EXTRA_TEXT);
      candidates.add(big);candidates.add(text);
      for(CharSequence candidate:candidates){
        AccountMessage parsed=AccountMessage.parse(candidate==null?null:candidate.toString());
        if(parsed!=null){
          try { saveIfNew(pkg,group,title,parsed,stableFallbackTime(notification,sbn),sbn.getPostTime()); }
          catch(RuntimeException e) { ProbeLog.append(this,"تعذر حفظ نص إشعار: "+e.getClass().getSimpleName()); }
          break;
        }
      }
    }
  }

  private long stableFallbackTime(Notification n,StatusBarNotification sbn){
    return n.when>0?n.when:sbn.getPostTime();
  }

  private String senderOf(Notification.MessagingStyle.Message m,String fallback){
    try{
      if(Build.VERSION.SDK_INT>=28){
        Person p=m.getSenderPerson();
        if(p!=null && p.getName()!=null && p.getName().length()>0)return p.getName().toString();
      }
    }catch(RuntimeException ignored){}
    try{
      CharSequence old=m.getSender();
      if(old!=null && old.length()>0)return old.toString();
    }catch(RuntimeException ignored){}
    return fallback==null?"":fallback;
  }

  private void saveIfNew(String pkg,String group,String sender,AccountMessage parsed,long messageTime,long receivedTime){
    if(sender==null)sender=""; if(group==null)group="";
    sender=cleanName(sender);group=cleanName(group);
    String source=group.isEmpty()?sender:group;
    if(source.isEmpty())return;

    String filter=getSharedPreferences("agent",MODE_PRIVATE).getString("names","").trim();
    if(!filter.isEmpty()){
      boolean selected=false;
      for(String candidate:filter.split("[,،\\n]")){
        String x=candidate.trim();
        if(!x.isEmpty() && (source.contains(x)||sender.contains(x)||group.contains(x))){selected=true;break;}
      }
      if(!selected)return;
    }

    String fingerprint=MessageIdentity.key(pkg,group,sender,parsed,messageTime);
    if(seen(fingerprint))return;

    BigDecimal gross=parsed.gross();
    BigDecimal pct=DiscountStore.percent(this,parsed.app);
    boolean configured=pct!=null;
    BigDecimal discount=DiscountStore.discount(gross,pct);
    BigDecimal net=gross.subtract(discount);
    String percentText=configured?pct.stripTrailingZeros().toPlainString()+"%":"غير محدد";
    String state=configured?"بانتظار التفاعل 🖥️":"بانتظار تحديد الخصم والتفاعل";

    String row=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(receivedTime))+"\t"+
      sender.replace('\t',' ')+"\t"+parsed.id+"\t"+gross+"\t"+parsed.app.replace('\t',' ')+"\t"+
      group.replace('\t',' ').replace('\n',' ')+"\t"+percentText+"\t"+discount+"\t"+net+"\t"+state+"\n";
    RecordStore.append(this,row);
    remember(fingerprint);
  }

  private synchronized boolean seen(String key){
    String raw=getSharedPreferences("agent",MODE_PRIVATE).getString("recent_message_keys","");
    for(String line:raw.split("\\n"))if(line.equals(key))return true;
    return false;
  }

  private synchronized void remember(String key){
    SharedPreferences p=getSharedPreferences("agent",MODE_PRIVATE);
    String raw=p.getString("recent_message_keys","");
    LinkedHashSet<String> keys=new LinkedHashSet<>();
    for(String line:raw.split("\\n"))if(!line.isEmpty())keys.add(line);
    keys.add(key);
    while(keys.size()>RECENT_LIMIT){Iterator<String> it=keys.iterator();if(it.hasNext()){it.next();it.remove();}else break;}
    StringBuilder b=new StringBuilder();for(String k:keys){if(b.length()>0)b.append('\n');b.append(k);}
    p.edit().putString("recent_message_keys",b.toString()).apply();
  }

  static String cleanName(String value){
    if(value==null)return "";
    String s=value.trim();
    s=s.replaceFirst("\\s*\\(\\s*(?:رسالة|رسالتان|[0-9٠-٩۰-۹]+\\s*(?:رسالة|رسائل)|[0-9]+\\s*(?:message|messages))\\s*\\)\\s*$","");
    return s.trim();
  }
}
