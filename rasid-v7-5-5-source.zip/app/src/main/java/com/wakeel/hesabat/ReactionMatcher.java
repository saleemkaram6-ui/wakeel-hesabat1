package com.wakeel.hesabat;
import java.util.*;

/** Pure tree matcher: links a reaction only inside the same unique accounting-message bubble. */
public final class ReactionMatcher {
  public static final class Node {
    String text="", description="", resource=""; boolean boundary;
    Node parent; final List<Node> children=new ArrayList<>();
    Node add(Node n){n.parent=this;children.add(n);return this;}
  }
  public static final class Result {
    public final AccountMessage message; public final boolean linked;
    Result(AccountMessage m,boolean l){message=m;linked=l;}
  }

  static String key(AccountMessage m){return m.id+"|"+m.amount+"|"+m.app;}
  static void addParsed(LinkedHashMap<String,AccountMessage> found,String raw){
    AccountMessage m=AccountMessage.parse(raw);
    if(m!=null)found.put(key(m),m);
  }
  static boolean emojiOnly(String s){
    if(s==null)return false;
    String x=s.replace("\uFE0F","").replaceAll("\\s+","").trim();
    return x.equals("🖥")||x.equals("🖥🖥");
  }
  static void atoms(Node n,List<String> out,int depth){
    if(n==null||depth>10||out.size()>24)return;
    if(n.text!=null&&!n.text.trim().isEmpty()&&!emojiOnly(n.text))out.add(n.text.trim());
    if(n.description!=null&&!n.description.trim().isEmpty()&&!n.description.trim().equals(n.text.trim())&&!emojiOnly(n.description))out.add(n.description.trim());
    for(Node c:n.children)atoms(c,out,depth+1);
  }

  /**
   * WhatsApp versions differ: some expose the whole 3-line message in one node,
   * others expose ID/amount/app as sibling text nodes. Return a message only when
   * this subtree contains exactly one distinct accounting message.
   */
  static AccountMessage message(Node n){
    LinkedHashMap<String,AccountMessage> found=new LinkedHashMap<>();
    addParsed(found,n.text); addParsed(found,n.description);
    List<String> values=new ArrayList<>(); atoms(n,values,0);
    for(String s:values)addParsed(found,s);
    for(int i=0;i+2<values.size();i++){
      addParsed(found,values.get(i)+"\n"+values.get(i+1)+"\n"+values.get(i+2));
    }
    return found.size()==1?found.values().iterator().next():null;
  }

  /** Find the deepest/minimal message containers, avoiding broad conversation nodes. */
  static void candidates(Node n,List<Node> out){
    int before=out.size();
    for(Node c:n.children)candidates(c,out);
    if(out.size()==before && message(n)!=null)out.add(n);
  }

  static boolean reaction(Node n){
    boolean marker=n.text.contains("🖥")||n.description.contains("🖥");
    if(!marker)return false;
    String meta=(n.resource+" "+n.description+" "+n.text).toLowerCase(Locale.ROOT);
    if(meta.contains("reaction")||meta.contains("reacted")||meta.contains("تفاعل")||meta.contains("رد فعل"))return true;
    // Some WhatsApp versions expose the reaction chip only as the emoji itself,
    // with no reaction resource id. It is accepted only when it is inside the
    // same unique accounting-message container (enforced by match()).
    return emojiOnly(n.text+" "+n.description);
  }
  static boolean hasReaction(Node n){if(reaction(n))return true;for(Node c:n.children)if(hasReaction(c))return true;return false;}
  static boolean hasEmoji(Node n){if(n.text.contains("🖥")||n.description.contains("🖥"))return true;for(Node c:n.children)if(hasEmoji(c))return true;return false;}

  public static List<Result> match(Node root){
    List<Node> messages=new ArrayList<>();candidates(root,messages);
    List<Result> out=new ArrayList<>();
    for(Node n:messages){boolean linked=false;int hops=0;
      // Keep the search local. Never cross a list/scroll boundary and never
      // accept an ancestor that contains more than one accounting message.
      for(Node scope=n;scope!=null&&scope!=root&&!scope.boundary&&hops++<8;scope=scope.parent){
        List<Node> local=new ArrayList<>();candidates(scope,local);
        if(local.size()!=1)break;
        if(hasReaction(scope)){linked=true;break;}
      }
      out.add(new Result(message(n),linked));
    }
    return out;
  }
}
