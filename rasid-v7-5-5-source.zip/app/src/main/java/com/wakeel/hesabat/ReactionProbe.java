package com.wakeel.hesabat;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Handler;
import android.os.Looper;
import java.util.*;

/** Reads the visible WhatsApp UI to link the local user's 🖥️ reaction. */
public class ReactionProbe extends AccessibilityService {
  private final Handler handler=new Handler(Looper.getMainLooper());
  private String lastLine=""; private int nodes; private boolean sawWhatsApp;
  private final Runnable scanTask=()->scan();
  @Override protected void onServiceConnected(){
    super.onServiceConnected();
    report("خدمة ربط التفاعل بدأت؛ افتح محادثة واتساب والتفاعل ظاهر عليها");
  }
  private void report(String value){
    if(value.equals(lastLine))return;
    lastLine=value;ProbeLog.append(this,value);
  }
  @Override public void onAccessibilityEvent(AccessibilityEvent e){
    if(e==null||e.getPackageName()==null)return;
    if(!String.valueOf(e.getPackageName()).matches("com\\.whatsapp(?:\\.w4b)?"))return;
    if(!sawWhatsApp){sawWhatsApp=true;report("وصل حدث واتساب؛ يجري فحص الرسائل والتفاعلات الظاهرة");}
    handler.removeCallbacks(scanTask);
    // A local reaction can appear after the click event. Scan twice so a slow
    // UI update does not leave the accounting row pending.
    handler.postDelayed(scanTask,220);
    handler.postDelayed(scanTask,900);
  }
  private void scan(){
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null){report("وصل حدث واتساب لكن تعذّر قراءة النافذة؛ افتح المحادثة من جديد");return;}
    try {
      String pkg=String.valueOf(root.getPackageName());
      if(!pkg.matches("com\\.whatsapp(?:\\.w4b)?")){report("وصل حدث واتساب لكن النافذة الحالية ليست واتساب");return;}
      nodes=0;ReactionMatcher.Node tree=copy(root,0);if(tree==null){report("وصل حدث واتساب لكن محتوى المحادثة غير متاح للخدمة");return;}
      List<ReactionMatcher.Result> results=ReactionMatcher.match(tree);
      StringBuilder line=new StringBuilder("مرشحات=").append(results.size()).append(" • رمز 🖥️ ظاهر=").append(ReactionMatcher.hasEmoji(tree)?"نعم":"لا");
      for(ReactionMatcher.Result r:results){
        boolean saved=r.linked&&RecordStore.markApproved(this,r.message);
        line.append("\nID: ").append(r.message.id).append(" • ").append(r.message.amount).append(" / ").append(r.message.app).append(" • ").append(r.linked?(saved?"تم ربط التفاعل 🖥️ بالسجل":"التفاعل 🖥️ مرتبط بالسجل"):"لا يوجد ربط مؤكّد بتفاعل 🖥️");
      }
      report(line.toString());
    } finally {root.recycle();}
  }
  private ReactionMatcher.Node copy(AccessibilityNodeInfo n,int depth){
    if(n==null||!n.isVisibleToUser()||depth>40||++nodes>1600)return null;
    ReactionMatcher.Node out=new ReactionMatcher.Node();
    out.text=n.getText()==null?"":n.getText().toString().trim();
    out.description=n.getContentDescription()==null?"":n.getContentDescription().toString().trim();
    out.resource=n.getViewIdResourceName()==null?"":n.getViewIdResourceName();
    String cls=String.valueOf(n.getClassName());
    out.boundary=n.isScrollable()||cls.contains("RecyclerView")||cls.contains("ListView")||cls.contains("ScrollView");
    for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo child=n.getChild(i);if(child!=null){try{ReactionMatcher.Node c=copy(child,depth+1);if(c!=null)out.add(c);}finally{child.recycle();}}}
    return out;
  }
  @Override public void onInterrupt(){handler.removeCallbacks(scanTask);}
  @Override public void onDestroy(){handler.removeCallbacks(scanTask);super.onDestroy();}
}
