package com.wakeel.hesabat;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ScrollView sc;
    String activePage="settings", rendered="";
    final Handler refreshHandler=new Handler(Looper.getMainLooper());
    final Runnable refreshTask=new Runnable(){ public void run(){ refreshVisible(); refreshHandler.postDelayed(this,500); } };
    @Override protected void onResume(){super.onResume();refreshHandler.removeCallbacks(refreshTask);refreshTask.run();}
    @Override protected void onPause(){refreshHandler.removeCallbacks(refreshTask);super.onPause();}
    void refreshVisible(){
        if(content==null || activePage.equals("settings"))return;
        String current=activePage.equals("log")?records():ProbeLog.read(this);
        if(current.equals(rendered))return;
        int y=sc.getScrollY();
        if(activePage.equals("log"))log();else reports();
        sc.post(()->sc.scrollTo(0,y));
    }
    EditText phone, account;
    Spinner trigger;
    TextView status, count, accountsList;
    final ArrayList<String> monitoredAccounts = new ArrayList<>();
    final int blue = Color.rgb(21,101,192), dark = Color.rgb(35,35,35), lightBlue = Color.rgb(227,242,253);
    static final int REQ_CONTACTS = 701;

    @Override public void onCreate(Bundle b){ super.onCreate(b); showApp(); }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        t.setPadding(18,14,18,14); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t;
    }
    Button btn(String s){
        Button x=new Button(this); x.setText(s); x.setAllCaps(false); x.setTextSize(16); x.setTextColor(Color.WHITE);
        x.setBackgroundColor(blue); x.setPadding(8,8,8,8); return x;
    }
    Button tab(String s){ Button x=btn(s); x.setTextSize(15); return x; }
    void gap(ViewGroup g,int h){ Space sp=new Space(this); g.addView(sp,new LinearLayout.LayoutParams(1,h)); }

    void showApp(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,18); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView title=tv("وكيل الحسابات",28); title.setTextColor(blue); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("اختبار 7.2 — رصد تفاعل 🖥️ وتحديث السجل تلقائيًا",16); sub.setGravity(Gravity.CENTER); root.addView(sub);
        gap(root,10);
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); tabs.setPadding(0,4,0,4);
        Button setup=tab("⚙ الإعدادات"); Button log=tab("📒 السجل"); Button reports=tab("📊 التقارير");
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,64,1); tp.setMargins(4,0,4,0);
        tabs.addView(setup,tp); tabs.addView(log,new LinearLayout.LayoutParams(tp)); tabs.addView(reports,new LinearLayout.LayoutParams(tp)); root.addView(tabs);
        gap(root,8);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(4,4,4,20);
        sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        setup.setOnClickListener(v->settings()); log.setOnClickListener(v->log()); reports.setOnClickListener(v->reports()); settings();
    }

    void settings(){
        activePage="settings";
        content.removeAllViews(); content.addView(tv("إعداد واتساب",22));
        TextView note=tv("يلتقط التطبيق الرسائل من إشعارات واتساب. عند فتح محادثة واتساب يرصد تفاعل 🖥️ للرسائل الظاهرة ويحدّث حالة السجل. حالة «رُصد تفاعل» تحتاج مراجعتك قبل اعتماد الحساب ماليًا.",14); note.setBackgroundColor(lightBlue); content.addView(note); gap(content,8);
        Button permission=btn("🔔 تفعيل الوصول إلى الإشعارات"); content.addView(permission); permission.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        Button accessibility=btn("♿ تفعيل اختبار واجهة واتساب");content.addView(accessibility);accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        content.addView(tv("إذن إمكانية الوصول يستطيع قراءة ما يظهر من نصوص على شاشة واتساب أثناء فتحها. يستخدمه هذا الاختبار لكشف الرسالة والرمز؛ تحفظ البيانات محليًا على الهاتف. يمكنك إيقافه من الإعدادات في أي وقت.",14));
        EditText names=new EditText(this); names.setHint("أسماء المجموعات المراد مراقبتها، مفصولة بفاصلة؛ اتركه فارغًا للكل"); names.setText(getSharedPreferences("agent",0).getString("names","")); content.addView(names);
        Button save=btn("حفظ أسماء المجموعات المراد مراقبتها");content.addView(save);save.setOnClickListener(v->{getSharedPreferences("agent",0).edit().putString("names",names.getText().toString().trim()).apply();Toast.makeText(this,"تم الحفظ",0).show();});
        content.addView(tv("التجربة: أرسل رسالتين مختلفتي الـID إلى هاتف الوكيل، وضع 🖥️ على الثانية فقط. افتح «السجل» لرؤية المرشحتين، ثم «التقارير» لرؤية ما رصدته شاشة واتساب. إذا لم تُظهر النتيجة ربطًا واضحًا، لا تعتمد أي حساب.",15));
    }

    void requestContacts(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},REQ_CONTACTS); }
        else showContactsPicker();
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ_CONTACTS && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) showContactsPicker(); else if(r==REQ_CONTACTS) Toast.makeText(this,"يلزم السماح بقراءة جهات الاتصال للاختيار",Toast.LENGTH_LONG).show(); }

    void showContactsPicker(){
        ArrayList<String> labels=new ArrayList<>();
        Cursor c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC");
        if(c!=null){ while(c.moveToNext()){ String n=c.getString(0), num=c.getString(1); String label=(n==null?"بدون اسم":n)+" — "+(num==null?"":num); if(!labels.contains(label)) labels.add(label); } c.close(); }
        if(labels.isEmpty()){ Toast.makeText(this,"لا توجد جهات اتصال متاحة",Toast.LENGTH_SHORT).show(); return; }
        boolean[] checked=new boolean[labels.size()];
        new AlertDialog.Builder(this).setTitle("اختر الحسابات/الأرقام").setMultiChoiceItems(labels.toArray(new String[0]),checked,(d,w,is)->checked[w]=is)
          .setPositiveButton("إضافة المحدد",(d,w)->{ int added=0; for(int i=0;i<labels.size();i++) if(checked[i] && !monitoredAccounts.contains(labels.get(i))){monitoredAccounts.add(labels.get(i));added++;} refreshAccounts(); Toast.makeText(this,"تمت إضافة "+added+" جهة اتصال",Toast.LENGTH_SHORT).show(); })
          .setNegativeButton("إلغاء",null).show();
    }
    void refreshAccounts(){ if(accountsList==null)return; if(monitoredAccounts.isEmpty()){accountsList.setText("الحسابات المضافة:\nلا توجد حسابات بعد");return;} StringBuilder s=new StringBuilder("الحسابات المضافة: ").append(monitoredAccounts.size()).append("\n"); for(String x:monitoredAccounts)s.append("• ").append(x).append("\n"); accountsList.setText(s.toString()); }

    String records(){try(java.io.InputStream in=openFileInput("pending.tsv")){byte[] data=new byte[in.available()];int n=in.read(data);String raw=n>0?new String(data,0,n,"UTF-8"):"";Set<String> linked=getSharedPreferences("agent",0).getStringSet("linked_reactions",Collections.emptySet());Set<String> unique=new HashSet<>(linked), all=new HashSet<>();Map<String,Integer> counts=new HashMap<>();for(String row:raw.split("\n")){String[] c=row.split("\t",-1);if(c.length==10){String key=ReactionStatus.key(c);all.add(key);counts.merge(key,1,Integer::sum);}}unique.removeIf(k->counts.getOrDefault(k,0)!=1);return ReactionStatus.update(raw,unique,all);}catch(Exception e){return "";}}
    void log(){ activePage="log"; rendered=records(); content.removeAllViews();content.addView(tv("سجل رسائل الحساب",22));String r=rendered;if(r.isEmpty()){content.addView(tv("لا توجد رسائل مطابقة بعد. أرسل اختبارًا بثلاثة أسطر: ID ثم مبلغ ثم اسم تطبيق.",16));return;}
      for(String line:r.split("\n")){String[] cells=line.split("\t",-1);if(cells.length<10)continue;
        String group=cells[5];String shown=group.isEmpty()?"لم يظهر اسم المجموعة في الإشعار":group;
        content.addView(tv("ID: "+cells[2]+"\nالتطبيق: "+cells[4]+" | المجموعة: "+shown+"\nالمبلغ: "+cells[3]+"$ | خصم: "+cells[7]+"$ | الصافي: "+cells[8]+"$\n"+cells[9],16));
      }
    }
    void reports(){ activePage="reports"; rendered=ProbeLog.read(this); content.removeAllViews();content.addView(tv("نتائج اختبار التفاعل",22));content.addView(tv("تحديث تلقائي. الربط البنيوي يعني وجود الرمز ضمن عناصر رسالة واحدة؛ يظل اختبارًا يحتاج مقارنة بواتساب ولا يعتمد حسابات تلقائيًا.",15));String report=rendered;content.addView(tv(report.isEmpty()?"لا توجد أحداث بعد؛ افتح واتساب وضع تفاعلًا ثم عد إلى هنا.":report,14));Button export=btn("حفظ مرشحي الاختبار لفتحهم في Excel");content.addView(export);export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/tab-separated-values");i.putExtra(Intent.EXTRA_TITLE,"وكيل-الحسابات-اختبار.tsv");startActivityForResult(i,811);}); }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==811&&result==RESULT_OK&&data!=null){try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){StringBuilder table=new StringBuilder("التاريخ\tالمحادثة\tID\tالمبلغ بالدولار\tالتطبيق\tاسم المجموعة\tنسبة الخصم\tقيمة الخصم\tالصافي بالدولار\tالحالة\n");for(String line:records().split("\n")){String[] cells=line.split("\t",-1);if(cells.length!=10)continue;table.append(android.text.TextUtils.join("\t",cells)).append('\n');}out.write(table.toString().getBytes("UTF-8"));Toast.makeText(this,"تم حفظ ملف الاختبار",0).show();}catch(Exception e){Toast.makeText(this,"تعذر حفظ الملف",1).show();}}}
}
