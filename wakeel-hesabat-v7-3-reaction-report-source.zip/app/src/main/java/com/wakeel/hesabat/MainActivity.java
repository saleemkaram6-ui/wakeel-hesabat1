package com.wakeel.hesabat;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfDocument;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ScrollView sc;
    String activePage="settings", rendered="";
    final Handler refreshHandler=new Handler(Looper.getMainLooper());
    final Runnable refreshTask=new Runnable(){ public void run(){ refreshVisible(); refreshHandler.postDelayed(this,500); } };
    @Override protected void onResume(){super.onResume();refreshHandler.removeCallbacks(refreshTask);refreshTask.run();}
    @Override protected void onPause(){refreshHandler.removeCallbacks(refreshTask);super.onPause();}
    void refreshVisible(){
        if(content==null || activePage.equals("settings"))return;
        String current=activePage.equals("log")?records():ProbeLog.read(this)+records();
        if(current.equals(rendered))return;
        int y=sc.getScrollY();
        if(activePage.equals("log"))log();else reports();
        sc.post(()->sc.scrollTo(0,y));
    }
    EditText phone, account;
    Spinner trigger;
    TextView status, count, accountsList;
    final ArrayList<String> monitoredAccounts = new ArrayList<>();
    final int blue = Color.rgb(29,78,216), dark = Color.rgb(24,39,65), lightBlue = Color.rgb(232,240,255);
    static final int REQ_CONTACTS = 701;

    @Override public void onCreate(Bundle b){ super.onCreate(b); showApp(); }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        t.setPadding(18,14,18,14); t.setTextDirection(View.TEXT_DIRECTION_RTL); t.setLineSpacing(4,1.05f); return t;
    }
    GradientDrawable background(int color,int radius){GradientDrawable shape=new GradientDrawable();shape.setColor(color);shape.setCornerRadius(radius);return shape;}
    TextView card(String s,int size,int accent){
        TextView t=tv(s,size);t.setBackground(background(Color.WHITE,26));t.setPadding(22,22,22,22);
        t.setElevation(3);t.setTextColor(accent);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(2,8,2,10);content.addView(t,lp);return t;
    }
    Button btn(String s){
        Button x=new Button(this); x.setText(s); x.setAllCaps(false); x.setTextSize(16); x.setTextColor(Color.WHITE);
        x.setBackground(background(blue,20)); x.setPadding(12,10,12,10);x.setElevation(2);return x;
    }
    Button tab(String s){ Button x=btn(s); x.setTextSize(15); return x; }
    void gap(ViewGroup g,int h){ Space sp=new Space(this); g.addView(sp,new LinearLayout.LayoutParams(1,h)); }

    void showApp(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(16,20,16,12); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackgroundColor(Color.rgb(246,248,252));
        TextView title=tv("رصيد",27); title.setTextColor(dark);title.setTypeface(null,Typeface.BOLD); root.addView(title,new LinearLayout.LayoutParams(-1,-2));
        TextView sub=tv("رسائلك وحساباتك في مكان واحد  •  نسخة 7.3",14);sub.setTextColor(Color.rgb(96,112,135));root.addView(sub);
        gap(root,8);
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); tabs.setPadding(0,4,0,4);
        Button setup=tab("⚙ الإعدادات"); Button log=tab("📒 السجل"); Button reports=tab("📊 التقارير");
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,56,1); tp.setMargins(3,0,3,0);
        tabs.addView(setup,tp); tabs.addView(log,new LinearLayout.LayoutParams(tp)); tabs.addView(reports,new LinearLayout.LayoutParams(tp)); root.addView(tabs);
        gap(root,8);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(3,10,3,28);
        sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        setup.setOnClickListener(v->settings()); log.setOnClickListener(v->log()); reports.setOnClickListener(v->reports()); settings();
    }

    void settings(){
        activePage="settings";
        content.removeAllViews(); content.addView(tv("إعداد واتساب",22));
        card("يلتقط التطبيق الرسائل من إشعارات واتساب. عند فتح المحادثة يرصد تفاعل 🖥️ ويحدّث السجل. راجع الحساب قبل اعتماده ماليًا.",15,dark);gap(content,8);
        Button permission=btn("🔔 تفعيل الوصول إلى الإشعارات"); content.addView(permission); permission.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));
        Button accessibility=btn("♿ تفعيل اختبار واجهة واتساب");content.addView(accessibility);accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        card("إمكانية الوصول تقرأ الرسائل الظاهرة على شاشة واتساب عند فتح المحادثة. تُحفظ نتائج التجربة على هاتفك.",14,Color.rgb(80,97,120));
        EditText names=new EditText(this); names.setHint("أسماء المجموعات المراد مراقبتها، مفصولة بفاصلة؛ اتركه فارغًا للكل"); names.setText(getSharedPreferences("agent",0).getString("names","")); content.addView(names);
        Button save=btn("حفظ أسماء المجموعات المراد مراقبتها");content.addView(save);save.setOnClickListener(v->{getSharedPreferences("agent",0).edit().putString("names",names.getText().toString().trim()).apply();Toast.makeText(this,"تم الحفظ",0).show();});
        card("للتجربة: افتح واتساب، ضع 🖥️ على رسالة واحدة، ثم انتقل إلى السجل والتقارير لرؤية النتيجة.",15,dark);
    }

    void requestContacts(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},REQ_CONTACTS); }
        else showContactsPicker();
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ_CONTACTS && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) showContactsPicker(); else if(r==REQ_CONTACTS) Toast.makeText(this,"يلزم السماح بقراءة جهات الاتصال للاختيار",Toast.LENGTH_LONG).show(); }

    void showContactsPicker(){
        ArrayList<String> labels=new ArrayList<>();
        Cursor c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC");
        if(c!=null){ while(c.moveToNext()){ String n=c.getString(0), num=c.getString(1); String label=(n==null?"بدون اسم":n)+" — "+(num==null?"":num); if(!labels.contains(label)) labels.add(label); } c.close(); }
        if(labels.isEmpty()){ Toast.makeText(this,"لا توجد جهات اتصال متاحة",Toast.LENGTH_SHORT).show(); return; }
        boolean[] checked=new boolean[labels.size()];
        new AlertDialog.Builder(this).setTitle("اختر الحسابات/الأرقام").setMultiChoiceItems(labels.toArray(new String[0]),checked,(d,w,is)->checked[w]=is)
          .setPositiveButton("إضافة المحدد",(d,w)->{ int added=0; for(int i=0;i<labels.size();i++) if(checked[i] && !monitoredAccounts.contains(labels.get(i))){monitoredAccounts.add(labels.get(i));added++;} refreshAccounts(); Toast.makeText(this,"تمت إضافة "+added+" جهة اتصال",Toast.LENGTH_SHORT).show(); })
          .setNegativeButton("إلغاء",null).show();
    }
    void refreshAccounts(){ if(accountsList==null)return; if(monitoredAccounts.isEmpty()){accountsList.setText("الحسابات المضافة:\nلا توجد حسابات بعد");return;} StringBuilder s=new StringBuilder("الحسابات المضافة: ").append(monitoredAccounts.size()).append("\n"); for(String x:monitoredAccounts)s.append("• ").append(x).append("\n"); accountsList.setText(s.toString()); }

    String records(){try(java.io.InputStream in=openFileInput("pending.tsv")){byte[] data=new byte[in.available()];int n=in.read(data);String raw=n>0?new String(data,0,n,"UTF-8"):"";Set<String> linked=getSharedPreferences("agent",0).getStringSet("linked_reactions",Collections.emptySet());Set<String> unique=new HashSet<>(linked), all=new HashSet<>();Map<String,Integer> counts=new HashMap<>();for(String row:raw.split("\n")){String[] c=row.split("\t",-1);if(c.length==10){String key=ReactionStatus.key(c);all.add(key);counts.merge(key,1,Integer::sum);}}unique.removeIf(k->counts.getOrDefault(k,0)!=1);String updated=ReactionStatus.update(raw,unique,all);StringBuilder fixed=new StringBuilder();for(String row:updated.split("\n")){String[] c=row.split("\t",-1);if(c.length!=10)continue;AccountMessage m=AccountMessage.parse(c[2]+"\n"+c[3]+"\n"+c[4]);if(m!=null){c[6]=m.discountRate().multiply(new java.math.BigDecimal("100")).stripTrailingZeros().toPlainString()+"%";c[7]=m.discount().toPlainString();c[8]=m.net().toPlainString();}fixed.append(android.text.TextUtils.join("\t",c)).append('\n');}return fixed.toString();}catch(Exception e){return "";}}
    void log(){ activePage="log"; rendered=records(); content.removeAllViews();content.addView(tv("سجل رسائل الحساب",22));String r=rendered;if(r.isEmpty()){content.addView(tv("لا توجد رسائل مطابقة بعد. أرسل اختبارًا بثلاثة أسطر: ID ثم مبلغ ثم اسم تطبيق.",16));return;}
      for(String line:r.split("\n")){String[] cells=line.split("\t",-1);if(cells.length<10)continue;
        String group=cells[5];String shown=group.isEmpty()?"لم يظهر اسم المجموعة في الإشعار":group;
        card("● "+cells[9]+"\n\n"+cells[4]+"  •  ID "+cells[2]+"\nالمجموعة: "+shown+"\nالمبلغ "+cells[3]+"$   |   خصم "+cells[7]+"$\nالصافي "+cells[8]+"$",16,cells[9].startsWith("رُصد")?Color.rgb(4,120,87):dark);
      }
    }
    void reports(){ activePage="reports"; String probe=ProbeLog.read(this), rows=records();rendered=probe+rows; content.removeAllViews();content.addView(tv("تقرير الحسابات والخصومات",22));
      if(rows.isEmpty())content.addView(tv("لا توجد رسائل حساب بعد.",15));
      else for(String row:rows.split("\n")){String[] c=row.split("\t",-1);if(c.length!=10)continue;
        card(c[4]+"  •  ID "+c[2]+"\n"+(c[5].isEmpty()?"محادثة فردية: "+c[1]:"مجموعة واتساب: "+c[5])+"\n\nالمبلغ: "+c[3]+"$   |   الخصم: "+c[6]+"\nقيمة الخصم: "+c[7]+"$   |   الصافي: "+c[8]+"$\n"+c[9],15,dark);}
      Button pdf=btn("حفظ تقرير PDF");content.addView(pdf);pdf.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"رصيد-تقرير-الحسابات.pdf");startActivityForResult(i,812);});
      gap(content,8);Button export=btn("حفظ تقرير Excel");content.addView(export);export.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("text/tab-separated-values");i.putExtra(Intent.EXTRA_TITLE,"رصيد-تقرير-الحسابات.tsv");startActivityForResult(i,811);});
      content.addView(tv("نتائج اختبار التفاعل",22));content.addView(tv("الربط البنيوي مؤشر من شاشة واتساب؛ يحتاج مراجعتك قبل الاعتماد المالي.",15));content.addView(tv(probe.isEmpty()?"لا توجد أحداث بعد؛ افتح واتساب وضع تفاعلًا ثم عد إلى هنا.":probe,14)); }
    void savePdf(android.net.Uri uri)throws java.io.IOException{
      PdfDocument doc=new PdfDocument();Paint p=new Paint(Paint.ANTI_ALIAS_FLAG);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));p.setTextAlign(Paint.Align.RIGHT);
      int page=0,y=0;PdfDocument.Page current=null;
      try{
        String[] rows=records().split("\n");
        for(int index=0;index<rows.length;index++){
          String[] c=rows[index].split("\t",-1);if(c.length!=10)continue;
          if(current==null||y>690){if(current!=null)doc.finishPage(current);current=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++page).create());y=65;p.setColor(blue);p.setTextSize(24);p.setTypeface(Typeface.DEFAULT_BOLD);current.getCanvas().drawText("رصيد — تقرير الحسابات",555,y,p);y+=32;p.setTextSize(12);p.setTypeface(Typeface.DEFAULT);p.setColor(dark);current.getCanvas().drawText("التاريخ: "+new java.text.SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(new Date())+"    |    صفحة "+page,555,y,p);y+=24;}
          p.setColor(Color.rgb(228,234,244));current.getCanvas().drawLine(40,y,555,y,p);y+=27;p.setColor(dark);p.setTextSize(15);p.setTypeface(Typeface.DEFAULT_BOLD);
          current.getCanvas().drawText(c[4]+"  |  ID: "+c[2],555,y,p);y+=24;p.setTextSize(13);p.setTypeface(Typeface.DEFAULT);
          current.getCanvas().drawText(c[5].isEmpty()?"محادثة فردية: "+c[1]:"المجموعة: "+c[5],555,y,p);y+=23;
          current.getCanvas().drawText("المبلغ: "+c[3]+"$   |   الخصم: "+c[6]+"   |   قيمة الخصم: "+c[7]+"$",555,y,p);y+=23;
          current.getCanvas().drawText("الصافي: "+c[8]+"$   |   "+c[9],555,y,p);y+=37;
        }
        if(current==null){current=doc.startPage(new PdfDocument.PageInfo.Builder(595,842,++page).create());p.setColor(dark);p.setTextSize(18);current.getCanvas().drawText("لا توجد رسائل حساب بعد",555,70,p);}
        doc.finishPage(current);
        try(java.io.OutputStream out=getContentResolver().openOutputStream(uri)){if(out==null)throw new java.io.IOException("No output");doc.writeTo(out);}
      }finally{doc.close();}
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null)return;if(request==812){try{savePdf(data.getData());Toast.makeText(this,"تم حفظ تقرير PDF",0).show();}catch(Exception e){Toast.makeText(this,"تعذر حفظ PDF",1).show();}return;}if(request==811){try(java.io.OutputStream out=getContentResolver().openOutputStream(data.getData())){StringBuilder table=new StringBuilder("التاريخ\tاسم المحادثة أو المرسل\tID\tالمبلغ بالدولار\tالتطبيق\tاسم مجموعة واتساب\tنسبة الخصم\tقيمة الخصم\tالصافي بالدولار\tحالة التفاعل\tنوع المحادثة\n");for(String line:records().split("\n")){String[] cells=line.split("\t",-1);if(cells.length!=10)continue;table.append(android.text.TextUtils.join("\t",cells)).append('\t').append(cells[5].isEmpty()?"فردية":"مجموعة").append('\n');}out.write(table.toString().getBytes("UTF-8"));Toast.makeText(this,"تم حفظ تقرير الحسابات",0).show();}catch(Exception e){Toast.makeText(this,"تعذر حفظ الملف",1).show();}}}
}
