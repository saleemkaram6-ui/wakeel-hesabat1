package com.wakeel.hesabat;
import java.util.*;
/** Pure tree matcher: never associates a screen-wide emoji with every message. */
public final class ReactionMatcher {
  public static final class Node {
    String text="", description="", resource=""; boolean boundary;
    Node parent; final List<Node> children=new ArrayList<>();
    Node add(Node n){n.parent=this;children.add(n);return this;}
  }
  public static final class Result {
    public final AccountMessage message; public final boolean linked;
    Result(AccountMessage m,boolean l){message=m;linked=l;}
  }
  static AccountMessage message(Node n){
    AccountMessage m=AccountMessage.parse(n.text);
    return m!=null?m:AccountMessage.parse(n.description);
  }
  static void candidates(Node n,List<Node> out){
    if(message(n)!=null){out.add(n);return;}
    for(Node c:n.children)candidates(c,out);
  }
  static boolean reaction(Node n){
    boolean marker=n.text.contains("🖥")||n.description.contains("🖥");
    // Explicit reaction metadata only. A standalone emoji message is not evidence.
    String meta=(n.resource+" "+n.description).toLowerCase(Locale.ROOT);
    return marker&&(meta.contains("reaction")||meta.contains("تفاعل"));
  }
  static boolean hasReaction(Node n){if(reaction(n))return true;for(Node c:n.children)if(hasReaction(c))return true;return false;}
  static boolean hasEmoji(Node n){if(n.text.contains("🖥")||n.description.contains("🖥"))return true;for(Node c:n.children)if(hasEmoji(c))return true;return false;}
  public static List<Result> match(Node root){
    List<Node> messages=new ArrayList<>();candidates(root,messages);
    List<Result> out=new ArrayList<>();
    for(Node n:messages){boolean linked=false;
      // Stop at the conversation list/window, or at any ancestor with multiple messages.
      for(Node scope=n;scope!=null&&scope!=root&&!scope.boundary;scope=scope.parent){
        List<Node> local=new ArrayList<>();candidates(scope,local);
        if(local.size()!=1)break;
        if(hasReaction(scope)){linked=true;break;}
      }
      out.add(new Result(message(n),linked));
    }
    return out;
  }
}
