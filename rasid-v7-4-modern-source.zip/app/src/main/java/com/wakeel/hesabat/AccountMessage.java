package com.wakeel.hesabat;

import java.util.regex.Pattern;
import java.math.BigDecimal;
import java.math.RoundingMode;

/** Accounting message from a full chat or a flattened notification preview. */
public final class AccountMessage {
  private static final Pattern ID=Pattern.compile("[0-9٠-٩۰-۹]{4,20}");
  private static final Pattern AMOUNT=Pattern.compile("[0-9٠-٩۰-۹]+(?:[.,٫][0-9٠-٩۰-۹]{1,2})?");
  public final String id, amount, app;
  private AccountMessage(String id,String amount,String app){this.id=id;this.amount=amount;this.app=app;}
  static String digits(String s){StringBuilder b=new StringBuilder();for(char c:s.toCharArray()){int v=Character.digit(c,10);b.append(v>=0?(char)('0'+v):c);}return b.toString();}
  public static AccountMessage parse(String raw){if(raw==null)return null;String trimmed=raw.trim();String[] lines=trimmed.split("\\R");
    String id,amount,app;
    if(lines.length==3){id=lines[0].trim();amount=lines[1].trim();app=lines[2].trim();}
    else if(lines.length==1){
      // Notification previews can replace newlines with spaces. Require the
      // entire preview to match, so unrelated chat text cannot be imported.
      java.util.regex.Matcher m=Pattern.compile("^([0-9٠-٩۰-۹]{4,20})\\s+([0-9٠-٩۰-۹]+(?:[.,٫][0-9٠-٩۰-۹]{1,2})?)\\s+([\\p{L}][\\p{L}\\p{M} ]{0,59})$").matcher(trimmed);
      if(!m.matches())return null;
      id=m.group(1);amount=m.group(2);app=m.group(3).trim();
    }else return null;
    id=digits(id);amount=digits(amount).replace('٫','.').replace(',','.');
    if(!ID.matcher(id).matches()||!AMOUNT.matcher(amount).matches()||app.isEmpty()||app.length()>60||app.matches("[0-9 .]+"))return null;
    return new AccountMessage(id,amount,app);
  }
  public BigDecimal gross(){return new BigDecimal(amount).setScale(2,RoundingMode.HALF_UP);}
  public BigDecimal discountRate(){String name=app.trim();return (name.equalsIgnoreCase("زافا")||name.equals("زلفة")||name.equals("الزلفة")||name.equals("زلفا")||name.equals("الزلفا"))?new BigDecimal("0.07"):BigDecimal.ZERO;}
  public BigDecimal discount(){return gross().multiply(discountRate()).setScale(2,RoundingMode.HALF_UP);}
  public BigDecimal net(){return gross().subtract(discount());}
}
