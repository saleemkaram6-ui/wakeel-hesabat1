package com.wakeel.hesabat;
import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.os.Handler;
import android.os.Looper;
import java.util.*;

/** Visible WhatsApp UI only. Diagnostic results never approve financial records. */
public class ReactionProbe extends AccessibilityService {
  private final Handler handler=new Handler(Looper.getMainLooper());
  private String lastLine=""; private int nodes;
  private final Runnable scanTask=()->scan();
  @Override public void onAccessibilityEvent(AccessibilityEvent e){
    if(e==null||e.getPackageName()==null)return;
    if(!String.valueOf(e.getPackageName()).matches("com\\.whatsapp(?:\\.w4b)?"))return;
    handler.removeCallbacks(scanTask);handler.postDelayed(scanTask,250);
  }
  private void scan(){
    AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null)return;
    try {
      String pkg=String.valueOf(root.getPackageName());
      if(!pkg.matches("com\\.whatsapp(?:\\.w4b)?"))return;
      nodes=0;ReactionMatcher.Node tree=copy(root,0);if(tree==null)return;
      List<ReactionMatcher.Result> results=ReactionMatcher.match(tree);
      String pending=readPending();
      Set<String> linked=ReactionStatus.linkedUnique(results,pending);
      Set<String> visible=new HashSet<>();
      for(ReactionMatcher.Result r:results)visible.add(ReactionStatus.key(r.message));
      Set<String> saved=new HashSet<>(getSharedPreferences("agent",MODE_PRIVATE).getStringSet("linked_reactions",Collections.emptySet()));
      saved.removeAll(visible);
      saved.addAll(linked);
      getSharedPreferences("agent",MODE_PRIVATE).edit().putStringSet("linked_reactions",saved).apply();
      StringBuilder line=new StringBuilder("مرشحات=").append(results.size()).append(" • رمز 🖥️ ظاهر=").append(ReactionMatcher.hasEmoji(tree)?"نعم":"لا");
      for(ReactionMatcher.Result r:results)line.append("\nID: ").append(r.message.id).append(" • ").append(r.message.amount).append(" / ").append(r.message.app).append(" • ").append(r.linked?"ربط بنيوي بتفاعل 🖥️ — يحتاج تأكيد الاختبار":"لا يوجد ربط مؤكّد بتفاعل 🖥️");
      String value=line.toString();if(value.equals(lastLine))return;lastLine=value;ProbeLog.append(this,value);
    } finally {root.recycle();}
  }
  private String readPending(){
    try(java.io.InputStream in=openFileInput("pending.tsv")){
      byte[] data=new byte[in.available()];int n=in.read(data);
      return n>0?new String(data,0,n,"UTF-8"):"";
    }catch(java.io.IOException e){return "";}
  }
  private ReactionMatcher.Node copy(AccessibilityNodeInfo n,int depth){
    if(n==null||!n.isVisibleToUser()||depth>40||++nodes>1200)return null;
    ReactionMatcher.Node out=new ReactionMatcher.Node();
    out.text=n.getText()==null?"":n.getText().toString().trim();
    out.description=n.getContentDescription()==null?"":n.getContentDescription().toString().trim();
    out.resource=n.getViewIdResourceName()==null?"":n.getViewIdResourceName();
    String cls=String.valueOf(n.getClassName());
    out.boundary=n.isScrollable()||cls.contains("RecyclerView")||cls.contains("ListView")||cls.contains("ScrollView");
    for(int i=0;i<n.getChildCount();i++){AccessibilityNodeInfo child=n.getChild(i);if(child!=null){try{ReactionMatcher.Node c=copy(child,depth+1);if(c!=null)out.add(c);}finally{child.recycle();}}}
    return out;
  }
  @Override public void onInterrupt(){handler.removeCallbacks(scanTask);}
  @Override public void onDestroy(){handler.removeCallbacks(scanTask);super.onDestroy();}
}
