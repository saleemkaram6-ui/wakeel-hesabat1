package com.wakeel.hesabat;

import android.app.Notification;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import java.io.*;

public class MessageListener extends NotificationListenerService {
  @Override public void onNotificationPosted(StatusBarNotification sbn) {
    String pkg=sbn.getPackageName();
    if (!pkg.equals("com.whatsapp") && !pkg.equals("com.whatsapp.w4b")) return;
    Notification notification=sbn.getNotification();
    if (notification==null || (notification.flags & Notification.FLAG_GROUP_SUMMARY)!=0) return;
    Bundle extras=notification.extras;
    if (extras==null) return;
    String sender=String.valueOf(extras.getCharSequence(Notification.EXTRA_TITLE, "")).trim();
    CharSequence conversation=extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE);
    String group=conversation==null?"":conversation.toString().trim();
    // On some MessagingStyle group notifications the title holds the group name.
    if(group.isEmpty() && extras.getBoolean(Notification.EXTRA_IS_GROUP_CONVERSATION,false)) group=sender;
    String body=String.valueOf(extras.getCharSequence(Notification.EXTRA_TEXT, "")).trim();
    AccountMessage parsed=AccountMessage.parse(body);
    if (sender.isEmpty() || parsed==null) return;
    String filter=getSharedPreferences("agent",MODE_PRIVATE).getString("names","").trim();
    if (!filter.isEmpty()) {
      boolean selected=false;
      for(String candidate:filter.split("[,،\\n]")) if (!candidate.trim().isEmpty() && group.contains(candidate.trim())) selected=true;
      if (!selected) return;
    }
    String fingerprint=pkg+"|"+group+"|"+sender+"|"+parsed.id+"|"+parsed.amount+"|"+parsed.app;
    String last=getSharedPreferences("agent",MODE_PRIVATE).getString("last","");
    if (last.equals(fingerprint)) return;
    getSharedPreferences("agent",MODE_PRIVATE).edit().putString("last",fingerprint).apply();
    String row=new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm",java.util.Locale.getDefault()).format(new java.util.Date(sbn.getPostTime()))+"\t"+sender.replace('\t',' ')+"\t"+parsed.id+"\t"+parsed.gross()+"\t"+parsed.app.replace('\t',' ')+"\t"+group.replace('\t',' ').replace('\n',' ')+"\t"+parsed.discountRate().multiply(new java.math.BigDecimal("100"))+"%\t"+parsed.discount()+"\t"+parsed.net()+"\tبانتظار التحقق\n";
    try(FileOutputStream out=openFileOutput("pending.tsv",MODE_APPEND)){out.write(row.getBytes("UTF-8"));} catch(IOException ignored){}
  }
}
