package com.wakeel.hesabat;
import android.content.Context;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;
final class ProbeLog {
 static synchronized void append(Context c,String value){
  String line=new SimpleDateFormat("HH:mm:ss",Locale.getDefault()).format(new Date())+" • "+value+"\n\n";
  String previous=read(c);if(previous.length()>24000)previous=previous.substring(0,24000);
  try(FileOutputStream out=c.openFileOutput("probe.log",Context.MODE_PRIVATE)){out.write((line+previous).getBytes("UTF-8"));}catch(IOException ignored){}
 }
 static synchronized String read(Context c){try(FileInputStream in=c.openFileInput("probe.log")){ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] buf=new byte[4096];int n;while((n=in.read(buf))!=-1){b.write(buf,0,n);}return new String(b.toByteArray(),"UTF-8");}catch(IOException e){return "";}}
}
