package com.wakeel.hesabat;

import java.util.*;

/** Match a visible reaction to exactly one notification row; ambiguous rows stay pending. */
public final class ReactionStatus {
  private ReactionStatus(){}
  static String key(AccountMessage m){return m.id+"\t"+m.gross()+"\t"+m.app.trim();}
  static String key(String[] c){return c[2]+"\t"+c[3]+"\t"+c[4].trim();}
  public static Set<String> linkedUnique(List<ReactionMatcher.Result> visible,String pending){
    Map<String,Integer> counts=new HashMap<>();
    for(String row:pending.split("\n")){
      String[] c=row.split("\t",-1);
      if(c.length==10)counts.merge(key(c),1,Integer::sum);
    }
    Map<String,Integer> seen=new HashMap<>();
    Set<String> linked=new HashSet<>();
    for(ReactionMatcher.Result r:visible){
      String k=key(r.message);seen.merge(k,1,Integer::sum);
      if(r.linked)linked.add(k);
    }
    linked.removeIf(k->counts.getOrDefault(k,0)!=1||seen.getOrDefault(k,0)!=1);
    return linked;
  }
  public static String update(String pending,Set<String> linked,Set<String> visible){
    StringBuilder out=new StringBuilder();
    for(String row:pending.split("\n")){
      String[] c=row.split("\t",-1);
      if(c.length!=10)continue;
      if(visible.contains(key(c)))c[9]=linked.contains(key(c))?"رُصد تفاعل 🖥️ — يحتاج مراجعة":"بانتظار التحقق";
      out.append(String.join("\t",c)).append('\n');
    }
    return out.toString();
  }
}
