package com.wakeel.hesabat;
import java.util.*;
public class ReactionMatcherTest {
 static ReactionMatcher.Node node(String text){ReactionMatcher.Node n=new ReactionMatcher.Node();n.text=text;return n;}
 static ReactionMatcher.Node reaction(){ReactionMatcher.Node n=node("🖥️");n.resource="com.whatsapp:id/reactions";return n;}
 static void check(boolean b){if(!b)throw new AssertionError();}
 public static void main(String[] args){
  ReactionMatcher.Node root=node(""),list=node("");list.boundary=true;root.add(list);
  ReactionMatcher.Node a=node(""),b=node("");a.add(node("9999001\n30\nزافا"));b.add(node("9999002\n50\nزافا"));list.add(a).add(b);
  ReactionMatcher.Node mark=reaction();b.add(mark);
  List<ReactionMatcher.Result> r=ReactionMatcher.match(root);check(r.size()==2&&!r.get(0).linked&&r.get(1).linked);
  b.children.remove(mark);r=ReactionMatcher.match(root);check(!r.get(0).linked&&!r.get(1).linked);
  list.add(reaction());r=ReactionMatcher.match(root);check(!r.get(0).linked&&!r.get(1).linked);
  b.add(node("🖥️"));r=ReactionMatcher.match(root);check(!r.get(1).linked);
  a.add(reaction());r=ReactionMatcher.match(root);check(r.get(0).linked&&!r.get(1).linked);
  ReactionMatcher.Node ambiguous=node("");ambiguous.add(node("9999001\n30\nزافا")).add(node("9999002\n50\nزافا")).add(reaction());
  ReactionMatcher.Node win=node("");win.add(ambiguous);r=ReactionMatcher.match(win);check(!r.get(0).linked&&!r.get(1).linked);
  System.out.println("PASS: per-message association, removal, screen-wide marker, standalone emoji, ambiguity");
 }
}
