package com.wakeel.hesabat;
import java.util.*;
public class ReactionStatusTest {
  static ReactionMatcher.Result result(String body,boolean linked){return new ReactionMatcher.Result(AccountMessage.parse(body),linked);}
  static void check(boolean value){if(!value)throw new AssertionError();}
  public static void main(String[] args){
    AccountMessage zafa=AccountMessage.parse("1214895\n60\nزافا");
    AccountMessage zolfa=AccountMessage.parse("1214895\n60\nزلفا");
    check(zafa.discount().toPlainString().equals("4.20")&&zafa.net().toPlainString().equals("55.80"));
    check(zolfa.discount().toPlainString().equals("4.20")&&zolfa.net().toPlainString().equals("55.80"));
    String row="now\tأمي\t1214895\t60.00\tزلفة\t\t7%\t4.20\t55.80\tبانتظار التحقق\n";
    List<ReactionMatcher.Result> visible=Arrays.asList(result("1214895\n60\nزلفة",true));
    Set<String> matched=ReactionStatus.linkedUnique(visible,row);
    check(matched.size()==1);
    Set<String> seen=new HashSet<>(matched);
    check(ReactionStatus.update(row,matched,seen).contains("رُصد تفاعل"));
    check(ReactionStatus.linkedUnique(Arrays.asList(result("1214895\n60\nزلفة",false)),row).isEmpty());
    check(ReactionStatus.update(row,Collections.emptySet(),seen).contains("بانتظار التحقق"));
    check(ReactionStatus.linkedUnique(visible,row+row).isEmpty());
    check(ReactionStatus.linkedUnique(Arrays.asList(visible.get(0),visible.get(0)),row).isEmpty());
    System.out.println("PASS: unique reaction, removal, duplicate notification and screen candidates");
  }
}
