package com.wakeel.hesabat;
public final class NotificationPreviewTest {
  static void check(String input, boolean accepted){
    AccountMessage parsed=AccountMessage.parse(input);
    if((parsed!=null)!=accepted)throw new AssertionError(input);
    if(accepted && (!parsed.id.equals("1214890") || !parsed.amount.equals("30") || !parsed.app.equals("زلفة")))throw new AssertionError(input);
  }
  public static void main(String[] args){
    check("1214890\n30\nزلفة",true);
    check("1214890 30 زلفة",true);
    check("1214890   30   زلفة",true);
    check("أرسل 1214890 30 زلفة",false);
    check("1214890 30 زلفة مرحبًا!",false);
    check("1214890 30",false);
    System.out.println("NotificationPreviewTest passed");
  }
}
