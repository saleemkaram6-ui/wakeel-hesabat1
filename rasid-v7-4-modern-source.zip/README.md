# وكيل الحسابات — اختبار 7

نسخة مستقلة باسم «وكيل الحسابات 7» للحفاظ على التطبيق السابق وبياناته.
- تحديث السجل والتقارير كل 500 مللي ثانية أثناء العرض وعند العودة للتطبيق.
- المحافظة على موضع التمرير وعدم إعادة إنشاء صفحة الإعدادات أثناء الكتابة.
- أحدث نتيجة اختبار تظهر أولًا.
- ربط تشخيصي عند وجود رمز شاشة مع بيانات تفاعل داخل شجرة رسالة واحدة.
- عدم ربط الرمز العام أو الرسائل المنفصلة بجميع الحسابات.
- لا تعتمد العمليات المالية تلقائيًا، ولا تدّعي تأكيد التفاعل عند غموض عناصر واتساب.
- قراءة واجهة واتساب تتطلب فتح المحادثة على الهاتف؛ تحديث صفحات التطبيق لا يغيّر هذا القيد.

اختبار الهاتف: إرسال رسالتين تجريبيتين مختلفتين ووضع 🖥️ على الثانية فقط، ثم العودة مباشرة إلى التقارير.
ينبغي أن يظهر ربط للثانية فقط إذا أتاح واتساب بنية التفاعل. بعد إزالة التفاعل، يجب أن تصبح نتيجة الفحص الجديدة غير مؤكدة.

اختبارات المنطق:
```
javac -d /tmp/wakeel-tests app/src/main/java/com/wakeel/hesabat/AccountMessage.java app/src/main/java/com/wakeel/hesabat/ReactionMatcher.java tests/ReactionMatcherTest.java
java -cp /tmp/wakeel-tests com.wakeel.hesabat.ReactionMatcherTest
```

## تحديث 7.1
- قراءة نص الإشعار سواء ظهر بثلاثة أسطر أو كسطر واحد بصيغة `ID مبلغ تطبيق`.
- رقم الإصدار 8، مع الاحتفاظ بمعرّف التطبيق نفسه حتى يُثبّت تحديثًا فوق اختبار 7 ويحافظ على السجل.
- صورة شريط الإشعارات وحدها لا تؤكد أن التطبيق تلقى إشعارًا كاملاً أو أن خدمة الاستماع تعمل؛ الاختبار النهائي على الهاتف مطلوب.
- بعد تثبيت APK الناتج، افتح السجل وأرسل رسالة جديدة مختلفة الـID من هاتف آخر، من دون فتح واتساب على هاتف الوكيل. يجب أن يظهر سجل «بانتظار التحقق» تلقائيًا. إذا لم يظهر، افحص أسماء المجموعات المحفوظة وإذن الوصول إلى الإشعارات.


## 7.2 reaction status preview
When WhatsApp is open, a uniquely matched message with a visible 🖥️ reaction is marked "رُصد تفاعل 🖥️ — يحتاج مراجعة" in the local log and TSV export. Removing the reaction while the message is visible resets the status. Duplicate notification rows or duplicate visible messages remain pending. This is a visual indicator, not a final financial approval.

## 7.3 report
Reports show the notification group name when available, sender for individual chats, and the 7% discount for زافا / زلفا including older pending records. A $60 transaction has a $4.20 discount and $55.80 net.
