package com.wakeel.hesabat;

import android.app.*;import android.os.*;import android.graphics.Color;import android.content.*;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, content; EditText phone, account; Spinner trigger; TextView status, count;
 int blue=Color.rgb(21,101,192); @Override public void onCreate(Bundle b){super.onCreate(b); showApp();}
 TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.DKGRAY);t.setPadding(16,12,16,12);t.setTextDirection(View.TEXT_DIRECTION_RTL);return t;}
 Button btn(String s){Button x=new Button(this);x.setText(s);x.setAllCaps(false);return x;}
 void showApp(){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(18,18,18,18);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
  TextView title=tv("وكيل الحسابات",28);title.setTextColor(blue);title.setGravity(Gravity.CENTER);root.addView(title,new LinearLayout.LayoutParams(-1,70));
  TextView sub=tv("نسخة V1 — إدارة الحسابات والعمليات",16);sub.setGravity(Gravity.CENTER);root.addView(sub);
  LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);
  Button setup=btn("الإعدادات");Button log=btn("سجل الحسابات");Button reports=btn("التقارير");tabs.addView(setup,new LinearLayout.LayoutParams(0,60,1));tabs.addView(log,new LinearLayout.LayoutParams(0,60,1));tabs.addView(reports,new LinearLayout.LayoutParams(0,60,1));root.addView(tabs);
  content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);ScrollView sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
  setup.setOnClickListener(v->settings());log.setOnClickListener(v->log());reports.setOnClickListener(v->reports());settings(); }
 void settings(){content.removeAllViews();content.addView(tv("إعداد واتساب",22));phone=new EditText(this);phone.setHint("رقم واتساب الذي سيُربط لاحقاً");phone.setInputType(3);phone.setSingleLine(true);content.addView(phone);account=new EditText(this);account.setHint("اسم/رقم الحساب المراد مراقبته");account.setSingleLine(true);content.addView(account);
  content.addView(tv("إشارة التشغيل",18));trigger=new Spinner(this);String[] a={"👍 لايك","❤️ قلب","✅ تأكيد","⭐ نجمة","🔥 نار"};trigger.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a));content.addView(trigger);
  Button add=btn("➕ إضافة الحساب");content.addView(add);TextView list=tv("الحسابات المضافة:\n• بابا أبو كرم (مثال تجريبي)",17);content.addView(list);status=tv("🔴 الوكيل متوقف",18);content.addView(status);Button on=btn("▶ تشغيل الوكيل");Button off=btn("⏹ إيقاف الوكيل");content.addView(on);content.addView(off);count=tv("العمليات المسجلة: 0",18);content.addView(count);add.setOnClickListener(v->{if(account.getText().length()>0){list.setText("الحسابات المضافة:\n• "+account.getText().toString()); Toast.makeText(this,"تمت إضافة الحساب",Toast.LENGTH_SHORT).show();}});on.setOnClickListener(v->{status.setText("🟢 الوكيل يعمل — بانتظار الإشارة");});off.setOnClickListener(v->{status.setText("🔴 الوكيل متوقف");}); }
 void log(){content.removeAllViews();content.addView(tv("سجل الحسابات",22));content.addView(tv("التاريخ | الشخص | البيان | المبلغ | المدين | الدائن | العملة\nلا توجد عمليات حقيقية بعد.\n\nسيتم ربط السجل مع Excel بعد ربط واتساب الرسمي.",17));Button demo=btn("🧪 إضافة عملية تجريبية");content.addView(demo);demo.setOnClickListener(v->{content.addView(tv("20/09/2026 | بابا أبو كرم | شراء مواد | 150 | 150 | — | USD",16));});}
 void reports(){content.removeAllViews();content.addView(tv("التقارير والتصدير",22));content.addView(tv("📊 Excel\nسيتم تصدير سجل الحسابات إلى ملف Excel.\n\n📄 PDF\nسيتم إنشاء تقرير يومي / أسبوعي / شهري.",17));}
}
