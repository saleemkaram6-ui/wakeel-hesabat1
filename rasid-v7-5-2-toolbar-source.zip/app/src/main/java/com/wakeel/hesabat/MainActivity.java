package com.wakeel.hesabat;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.provider.Settings;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.math.BigDecimal;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    ScrollView sc;
    String activePage="log", rendered="";
    final Handler refreshHandler=new Handler(Looper.getMainLooper());
    final Runnable refreshTask=new Runnable(){ public void run(){ refreshVisible(); refreshHandler.postDelayed(this,500); } };
    final int navy=Color.rgb(18,70,130), blue=Color.rgb(35,105,190), ink=Color.rgb(35,42,52), muted=Color.rgb(103,113,128), bg=Color.rgb(245,247,250), card=Color.WHITE, soft=Color.rgb(232,240,250);

    @Override protected void onCreate(Bundle b){super.onCreate(b);showApp();}
    @Override protected void onResume(){super.onResume();refreshHandler.removeCallbacks(refreshTask);refreshTask.run();}
    @Override protected void onPause(){refreshHandler.removeCallbacks(refreshTask);super.onPause();}

    GradientDrawable shape(int color,float radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    int dp(float value){return (int)(getResources().getDisplayMetrics().density*value+0.5f);}
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(ink);t.setPadding(18,14,18,14);t.setTextDirection(View.TEXT_DIRECTION_RTL);return t;}
    TextView small(String s){TextView t=tv(s,13);t.setTextColor(muted);return t;}
    Button btn(String s){Button x=new Button(this);x.setText(s);x.setAllCaps(false);x.setTextSize(15);x.setTextColor(Color.WHITE);x.setBackground(shape(blue,18));x.setPadding(10,6,10,6);return x;}
    Button lightBtn(String s){Button x=new Button(this);x.setText(s);x.setAllCaps(false);x.setTextSize(13);x.setTextColor(navy);x.setMinWidth(0);x.setMinimumWidth(0);x.setMinHeight(0);x.setMinimumHeight(0);x.setPadding(dp(4),0,dp(4),0);x.setGravity(Gravity.CENTER);x.setBackground(shape(soft,dp(12)));return x;}
    void gap(ViewGroup g,int h){Space sp=new Space(this);g.addView(sp,new LinearLayout.LayoutParams(1,h));}
    LinearLayout cardBox(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(14,12,14,12);box.setBackground(shape(card,22));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,12);box.setLayoutParams(p);return box;}

    void showApp(){
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);root.setBackgroundColor(bg);

        LinearLayout toolbar=new LinearLayout(this);toolbar.setOrientation(LinearLayout.HORIZONTAL);toolbar.setGravity(Gravity.CENTER_VERTICAL);toolbar.setPadding(dp(8),dp(8),dp(8),dp(8));toolbar.setBackgroundColor(navy);
        TextView brand=tv("رصيد",23);brand.setPadding(dp(4),0,dp(4),0);brand.setTextColor(Color.WHITE);brand.setGravity(Gravity.CENTER_VERTICAL);toolbar.addView(brand,new LinearLayout.LayoutParams(0,dp(48),1));
        Button excel=lightBtn("Excel");Button pdf=lightBtn("PDF");Button more=lightBtn("⋮");
        LinearLayout.LayoutParams xp=new LinearLayout.LayoutParams(dp(62),dp(44));xp.setMargins(dp(2),0,dp(2),0);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(dp(48),dp(44));pp.setMargins(dp(2),0,dp(2),0);
        LinearLayout.LayoutParams mp=new LinearLayout.LayoutParams(dp(38),dp(44));mp.setMargins(dp(2),0,dp(2),0);
        toolbar.addView(excel,xp);toolbar.addView(pdf,pp);toolbar.addView(more,mp);
        root.addView(toolbar);
        excel.setOnClickListener(v->pickXlsx());pdf.setOnClickListener(v->pickPdf());more.setOnClickListener(v->showMenu(more));

        TextView sub=small("سجل حسابات واتساب • خصومات مستقلة لكل تطبيق • تحديث تلقائي");sub.setGravity(Gravity.CENTER);root.addView(sub);

        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.VERTICAL);tabs.setPadding(dp(8),dp(4),dp(8),dp(8));
        Button log=lightBtn("📒 السجل");Button reports=lightBtn("📊 التقارير");Button discounts=lightBtn("% الخصومات");Button setup=lightBtn("⚙ الإعدادات");
        LinearLayout first=new LinearLayout(this);first.setOrientation(LinearLayout.HORIZONTAL);first.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout second=new LinearLayout(this);second.setOrientation(LinearLayout.HORIZONTAL);second.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,dp(48),1);tp.setMargins(dp(3),0,dp(3),0);
        first.addView(log,tp);first.addView(reports,new LinearLayout.LayoutParams(tp));
        second.addView(discounts,new LinearLayout.LayoutParams(tp));second.addView(setup,new LinearLayout.LayoutParams(tp));
        tabs.addView(first);tabs.addView(second);root.addView(tabs);

        content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(14,8,14,30);
        sc=new ScrollView(this);sc.addView(content);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);
        log.setOnClickListener(v->log());reports.setOnClickListener(v->reports());discounts.setOnClickListener(v->discounts());setup.setOnClickListener(v->settings());
        log();
    }

    void showMenu(View anchor){PopupMenu m=new PopupMenu(this,anchor);m.getMenu().add("السجل");m.getMenu().add("التقارير");m.getMenu().add("التطبيقات والخصومات");m.getMenu().add("الإعدادات");m.setOnMenuItemClickListener(i->{String s=i.getTitle().toString();if(s.equals("السجل"))log();else if(s.equals("التقارير"))reports();else if(s.contains("الخصومات"))discounts();else settings();return true;});m.show();}

    void refreshVisible(){
        if(content==null||activePage.equals("settings")||activePage.equals("discounts"))return;
        String current=activePage.equals("log")?RecordStore.read(this):reportSignature();
        if(current.equals(rendered))return;
        int y=sc.getScrollY();if(activePage.equals("log"))log();else reports();sc.post(()->sc.scrollTo(0,y));
    }
    String reportSignature(){return RecordStore.read(this)+"\n"+ProbeLog.read(this);}

    void settings(){
        activePage="settings";content.removeAllViews();content.addView(tv("الإعدادات",23));
        LinearLayout box=cardBox();box.addView(tv("ربط واتساب",18));box.addView(small("فعّل وصول الإشعارات لالتقاط رسائل الحساب، وفعّل إمكانية الوصول لربط تفاعل 🖥️ بالرسالة الظاهرة داخل واتساب."));
        Button notification=btn("🔔 تفعيل الوصول إلى الإشعارات");Button accessibility=btn("♿ تفعيل قراءة واجهة واتساب");box.addView(notification);gap(box,8);box.addView(accessibility);content.addView(box);
        notification.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)));accessibility.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        LinearLayout filters=cardBox();filters.addView(tv("المجموعات المراقبة",18));EditText names=new EditText(this);names.setHint("أسماء المجموعات مفصولة بفاصلة — فارغ = الكل");names.setText(getSharedPreferences("agent",0).getString("names",""));names.setTextDirection(View.TEXT_DIRECTION_RTL);filters.addView(names);Button save=btn("حفظ المجموعات");filters.addView(save);content.addView(filters);
        save.setOnClickListener(v->{getSharedPreferences("agent",0).edit().putString("names",names.getText().toString().trim()).apply();Toast.makeText(this,"تم حفظ المجموعات",Toast.LENGTH_SHORT).show();});
        content.addView(small("صيغة الرسالة: السطر الأول ID، السطر الثاني المبلغ بالدولار، السطر الثالث اسم التطبيق. كل رسالة تُحفظ كسجل مستقل مع اسم المجموعة."));
    }

    void discounts(){
        activePage="discounts";content.removeAllViews();content.addView(tv("التطبيقات والخصومات",23));
        LinearLayout edit=cardBox();edit.addView(small("لكل تطبيق نسبة خصم مستقلة. إذا ظهر تطبيق جديد بلا نسبة محفوظة فلن يخمّن رصيد الخصم، وسيعلّم السجل بأنه غير محدد."));
        EditText app=new EditText(this);app.setHint("اسم التطبيق — مثال: زافا");app.setTextDirection(View.TEXT_DIRECTION_RTL);edit.addView(app);
        EditText pct=new EditText(this);pct.setHint("نسبة الخصم % — مثال: 7");pct.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);edit.addView(pct);
        Button save=btn("حفظ التطبيق ونسبة الخصم");edit.addView(save);content.addView(edit);
        save.setOnClickListener(v->{if(!DiscountStore.save(this,app.getText().toString(),pct.getText().toString())){Toast.makeText(this,"أدخل اسم تطبيق ونسبة من 0 إلى 100",Toast.LENGTH_LONG).show();return;}RecordStore.recalculate(this);Toast.makeText(this,"تم الحفظ وإعادة حساب السجلات",Toast.LENGTH_SHORT).show();discounts();});

        LinkedHashMap<String,BigDecimal> rules=DiscountStore.all(this);
        if(rules.isEmpty()){content.addView(small("لا توجد تطبيقات مضافة بعد."));return;}
        for(Map.Entry<String,BigDecimal> e:rules.entrySet()){
            LinearLayout row=cardBox();LinearLayout top=new LinearLayout(this);top.setOrientation(LinearLayout.HORIZONTAL);top.setGravity(Gravity.CENTER_VERTICAL);
            TextView name=tv(e.getKey()+"  •  "+e.getValue().stripTrailingZeros().toPlainString()+"%",17);top.addView(name,new LinearLayout.LayoutParams(0,-2,1));Button del=lightBtn("حذف");top.addView(del,new LinearLayout.LayoutParams(-2,48));row.addView(top);content.addView(row);
            String n=e.getKey();del.setOnClickListener(v->{new AlertDialog.Builder(this).setTitle("حذف الخصم؟").setMessage("سيصبح خصم "+n+" غير محدد في السجلات.").setPositiveButton("حذف",(d,w)->{DiscountStore.delete(this,n);RecordStore.recalculate(this);discounts();}).setNegativeButton("إلغاء",null).show();});
            row.setOnClickListener(v->{app.setText(n);pct.setText(e.getValue().stripTrailingZeros().toPlainString());sc.smoothScrollTo(0,0);});
        }
    }

    void log(){
        activePage="log";rendered=RecordStore.read(this);content.removeAllViews();content.addView(tv("سجل الرسائل",23));
        List<String[]> rows=ExportUtil.rows(rendered);if(rows.isEmpty()){content.addView(small("لا توجد رسائل مطابقة بعد. أرسل رسالة بثلاثة أسطر: ID ثم المبلغ ثم اسم التطبيق."));return;}
        for(int i=rows.size()-1;i>=0;i--){String[] c=rows.get(i);LinearLayout box=cardBox();String group=c[5].isEmpty()?"لم يظهر اسم المجموعة":c[5];
            TextView head=tv("ID  "+c[2]+"   •   "+c[4],18);head.setTextColor(navy);box.addView(head);
            box.addView(tv("المبلغ: "+c[3]+"$\nالخصم: "+c[6]+"  ("+c[7]+"$)\nالصافي: "+c[8]+"$\nالمجموعة: "+group+"\nالحالة: "+c[9],15));box.addView(small(c[0]));content.addView(box);
        }
    }

    void reports(){
        activePage="reports";rendered=reportSignature();content.removeAllViews();content.addView(tv("التقارير",23));
        List<String[]> rows=ExportUtil.rows(RecordStore.read(this));int approved=0;BigDecimal gross=BigDecimal.ZERO,discount=BigDecimal.ZERO,net=BigDecimal.ZERO;
        LinkedHashMap<String,BigDecimal[]> perApp=new LinkedHashMap<>();
        for(String[] r:rows){if(!r[9].contains("معتمد"))continue;approved++;try{gross=gross.add(new BigDecimal(r[3]));discount=discount.add(new BigDecimal(r[7]));net=net.add(new BigDecimal(r[8]));BigDecimal[] a=perApp.get(r[4]);if(a==null){a=new BigDecimal[]{BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO,BigDecimal.ZERO};perApp.put(r[4],a);}a[0]=a[0].add(BigDecimal.ONE);a[1]=a[1].add(new BigDecimal(r[3]));a[2]=a[2].add(new BigDecimal(r[7]));a[3]=a[3].add(new BigDecimal(r[8]));}catch(Exception ignored){}
        }
        LinearLayout summary=cardBox();summary.addView(tv("المعتمد بتفاعل 🖥️: "+approved+" سجل",18));summary.addView(tv("إجمالي المبالغ: "+gross+"$\nإجمالي الخصومات: "+discount+"$\nصافي الحسابات: "+net+"$",16));content.addView(summary);
        for(Map.Entry<String,BigDecimal[]> e:perApp.entrySet()){BigDecimal[] a=e.getValue();LinearLayout box=cardBox();box.addView(tv(e.getKey(),18));box.addView(tv("عدد العمليات: "+a[0].intValue()+"\nالمبالغ: "+a[1]+"$\nالخصومات: "+a[2]+"$\nالصافي: "+a[3]+"$",15));content.addView(box);}
        LinearLayout exports=cardBox();exports.addView(tv("التصدير",18));Button x=btn("تصدير Excel (.xlsx)");Button p=btn("تصدير تقرير PDF");exports.addView(x);gap(exports,8);exports.addView(p);content.addView(exports);x.setOnClickListener(v->pickXlsx());p.setOnClickListener(v->pickPdf());
        String probe=ProbeLog.read(this);if(!probe.isEmpty()){LinearLayout diag=cardBox();diag.addView(tv("آخر فحص للتفاعل",17));diag.addView(small(probe.length()>1800?probe.substring(0,1800):probe));content.addView(diag);}
    }

    void pickXlsx(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");i.putExtra(Intent.EXTRA_TITLE,"رصيد-تقرير-الحسابات.xlsx");startActivityForResult(i,811);}
    void pickPdf(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/pdf");i.putExtra(Intent.EXTRA_TITLE,"رصيد-تقرير-الحسابات.pdf");startActivityForResult(i,812);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;try{if(request==811){ExportUtil.writeXlsx(this,data.getData(),RecordStore.read(this));Toast.makeText(this,"تم حفظ ملف Excel الحقيقي",Toast.LENGTH_SHORT).show();}else if(request==812){ExportUtil.writePdf(this,data.getData(),RecordStore.read(this));Toast.makeText(this,"تم حفظ تقرير PDF",Toast.LENGTH_SHORT).show();}}catch(Exception e){Toast.makeText(this,"تعذر التصدير: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
}
