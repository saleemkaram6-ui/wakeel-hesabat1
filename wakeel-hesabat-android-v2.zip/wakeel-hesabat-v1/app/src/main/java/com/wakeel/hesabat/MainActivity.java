package com.wakeel.hesabat;

import android.Manifest;
import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content;
    EditText phone, account;
    Spinner trigger;
    TextView status, count, accountsList;
    final ArrayList<String> monitoredAccounts = new ArrayList<>();
    final int blue = Color.rgb(21,101,192), dark = Color.rgb(35,35,35), lightBlue = Color.rgb(227,242,253);
    static final int REQ_CONTACTS = 701;

    @Override public void onCreate(Bundle b){ super.onCreate(b); showApp(); }

    TextView tv(String s,int size){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(dark);
        t.setPadding(18,14,18,14); t.setTextDirection(View.TEXT_DIRECTION_RTL); return t;
    }
    Button btn(String s){
        Button x=new Button(this); x.setText(s); x.setAllCaps(false); x.setTextSize(16); x.setTextColor(Color.WHITE);
        x.setBackgroundColor(blue); x.setPadding(8,8,8,8); return x;
    }
    Button tab(String s){ Button x=btn(s); x.setTextSize(15); return x; }
    void gap(ViewGroup g,int h){ Space sp=new Space(this); g.addView(sp,new LinearLayout.LayoutParams(1,h)); }

    void showApp(){
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(18,18,18,18); root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        TextView title=tv("وكيل الحسابات",28); title.setTextColor(blue); title.setGravity(Gravity.CENTER); root.addView(title,new LinearLayout.LayoutParams(-1,72));
        TextView sub=tv("نسخة V2 — إدارة الحسابات والعمليات",16); sub.setGravity(Gravity.CENTER); root.addView(sub);
        gap(root,10);
        LinearLayout tabs=new LinearLayout(this); tabs.setOrientation(LinearLayout.HORIZONTAL); tabs.setPadding(0,4,0,4);
        Button setup=tab("⚙ الإعدادات"); Button log=tab("📒 السجل"); Button reports=tab("📊 التقارير");
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,64,1); tp.setMargins(4,0,4,0);
        tabs.addView(setup,tp); tabs.addView(log,new LinearLayout.LayoutParams(tp)); tabs.addView(reports,new LinearLayout.LayoutParams(tp)); root.addView(tabs);
        gap(root,8);
        content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(4,4,4,20);
        ScrollView sc=new ScrollView(this); sc.addView(content); root.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        setup.setOnClickListener(v->settings()); log.setOnClickListener(v->log()); reports.setOnClickListener(v->reports()); settings();
    }

    void settings(){
        content.removeAllViews(); content.addView(tv("إعداد واتساب",22));
        TextView note=tv("يمكنك اختيار عدة جهات اتصال من الهاتف دفعة واحدة. الربط المباشر بمحادثات واتساب يحتاج تكاملاً رسمياً منفصلاً.",14); note.setBackgroundColor(lightBlue); content.addView(note); gap(content,8);
        phone=new EditText(this); phone.setHint("رقم واتساب الذي سيُربط لاحقاً"); phone.setInputType(3); phone.setSingleLine(true); content.addView(phone);
        account=new EditText(this); account.setHint("اسم/رقم حساب لإضافته يدوياً"); account.setSingleLine(true); content.addView(account);
        gap(content,8);
        Button choose=btn("👥 اختيار جهات الاتصال دفعة واحدة"); content.addView(choose,new LinearLayout.LayoutParams(-1,64)); gap(content,8);
        content.addView(tv("إشارة التشغيل",18)); trigger=new Spinner(this); String[] a={"👍 لايك","❤️ قلب","✅ تأكيد","⭐ نجمة","🔥 نار"}; trigger.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,a)); content.addView(trigger);
        gap(content,8);
        Button add=btn("➕ إضافة الحساب يدوياً"); content.addView(add,new LinearLayout.LayoutParams(-1,60));
        accountsList=tv("الحسابات المضافة:\nلا توجد حسابات بعد",17); content.addView(accountsList);
        status=tv("🔴 الوكيل متوقف",18); content.addView(status);
        Button on=btn("▶ تشغيل الوكيل"); Button off=btn("⏹ إيقاف الوكيل"); content.addView(on,new LinearLayout.LayoutParams(-1,60)); gap(content,8); content.addView(off,new LinearLayout.LayoutParams(-1,60));
        count=tv("العمليات المسجلة: 0",18); content.addView(count);
        choose.setOnClickListener(v->requestContacts());
        add.setOnClickListener(v->{ String s=account.getText().toString().trim(); if(!s.isEmpty()){ if(!monitoredAccounts.contains(s)) monitoredAccounts.add(s); account.setText(""); refreshAccounts(); Toast.makeText(this,"تمت إضافة الحساب",Toast.LENGTH_SHORT).show(); }});
        on.setOnClickListener(v->status.setText("🟢 الوكيل يعمل — بانتظار الإشارة")); off.setOnClickListener(v->status.setText("🔴 الوكيل متوقف"));
    }

    void requestContacts(){
        if(Build.VERSION.SDK_INT>=23 && checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){ requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},REQ_CONTACTS); }
        else showContactsPicker();
    }
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){ super.onRequestPermissionsResult(r,p,g); if(r==REQ_CONTACTS && g.length>0 && g[0]==PackageManager.PERMISSION_GRANTED) showContactsPicker(); else if(r==REQ_CONTACTS) Toast.makeText(this,"يلزم السماح بقراءة جهات الاتصال للاختيار",Toast.LENGTH_LONG).show(); }

    void showContactsPicker(){
        ArrayList<String> labels=new ArrayList<>();
        Cursor c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" ASC");
        if(c!=null){ while(c.moveToNext()){ String n=c.getString(0), num=c.getString(1); String label=(n==null?"بدون اسم":n)+" — "+(num==null?"":num); if(!labels.contains(label)) labels.add(label); } c.close(); }
        if(labels.isEmpty()){ Toast.makeText(this,"لا توجد جهات اتصال متاحة",Toast.LENGTH_SHORT).show(); return; }
        boolean[] checked=new boolean[labels.size()];
        new AlertDialog.Builder(this).setTitle("اختر الحسابات/الأرقام").setMultiChoiceItems(labels.toArray(new String[0]),checked,(d,w,is)->checked[w]=is)
          .setPositiveButton("إضافة المحدد",(d,w)->{ int added=0; for(int i=0;i<labels.size();i++) if(checked[i] && !monitoredAccounts.contains(labels.get(i))){monitoredAccounts.add(labels.get(i));added++;} refreshAccounts(); Toast.makeText(this,"تمت إضافة "+added+" جهة اتصال",Toast.LENGTH_SHORT).show(); })
          .setNegativeButton("إلغاء",null).show();
    }
    void refreshAccounts(){ if(accountsList==null)return; if(monitoredAccounts.isEmpty()){accountsList.setText("الحسابات المضافة:\nلا توجد حسابات بعد");return;} StringBuilder s=new StringBuilder("الحسابات المضافة: ").append(monitoredAccounts.size()).append("\n"); for(String x:monitoredAccounts)s.append("• ").append(x).append("\n"); accountsList.setText(s.toString()); }

    void log(){ content.removeAllViews(); content.addView(tv("سجل الحسابات",22)); content.addView(tv("التاريخ | الشخص | البيان | المبلغ | المدين | الدائن | العملة\nلا توجد عمليات حقيقية بعد.\n\nسيتم ربط السجل مع Excel بعد ربط واتساب الرسمي.",17)); Button demo=btn("🧪 إضافة عملية تجريبية"); content.addView(demo,new LinearLayout.LayoutParams(-1,60)); demo.setOnClickListener(v->content.addView(tv("20/09/2026 | مثال | شراء مواد | 150 | 150 | — | USD",16))); }
    void reports(){ content.removeAllViews(); content.addView(tv("التقارير والتصدير",22)); content.addView(tv("📊 Excel\nسيتم تصدير سجل الحسابات إلى ملف Excel.\n\n📄 PDF\nسيتم إنشاء تقرير يومي / أسبوعي / شهري.",17)); }
}
